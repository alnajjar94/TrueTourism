<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of mysqli_con
 *
 * @author 20130
 */
class mysqli_con {
        /**
     * initiates a connection between the website and database to send queries
     * 
     * takes nothing
     * @return type MySQLi connection AS link
     */
        private $dbc = NULL;
        public function __construct() {
            
        }
    function getConnection()
    {

        //for more info on this code go to http://php.net/manual/en/function.mysqli-connect.php
        //creating a connection
        if($this->dbc==NULL){
              $this->dbc = mysqli_connect('54.171.69.5','201301587','', 'Project_Schema');
        }
           if (mysqli_connect_errno()) {
                //printf("Connect failed: %s\n", mysqli_connect_error());
                die('b0ther');
            }
               
        

        return $this->dbc;
    }// function end
    
    
    public function closeDB()
    {
         mysqli_close($this->dbc);  
    }
    
    
}// class end
