<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * This class was coded by sayed mohammed alnajjar 201301587
 * with help from the Data Object Emitter program
*/


class DO_Site_Category extends mysqli_con {

	public $Category_ID=null;
	public $Category_Name;
	public $Category_Description;
	public $errorMsg;
	public $dbc=null;

	public function  __construct() /*DO_Site_Category() depricated name*/ {

		$this->getDBConnection();
}

	private function getDBConnection() {
		//replace with your own connection class
		include_once "mysqli_con.php";
		try{
			if($this->dbc == null){
				$db = new mysqli_con();
				$this->dbc = $db->getConnection();
			}
		return $this->dbc;
		}
		catch (Exception $e) {
			echo 'Caught exception: '.$e->getMessage();
			return null;
		}
	}


	public function get($Category_ID) {
		if($this->getDBConnection()){
			$q = "SELECT Category_ID, Category_Name, Category_Description FROM Site_Category where Category_ID=".$Category_ID;
			//create the prepared statement
			$stmt = $this->dbc->prepare($q);

			//bind the variables to the statement
			//$stmt->bind_param('s', $Category_ID);

			//execute the statement
			if ($stmt) {
                            
                                $stmt->execute();
                                
				/* store result */
				$stmt->store_result();

				//bind the output results to the members of the class
				$stmt->bind_result($this->Category_ID, $this->Category_Name, $this->Category_Description);

				//get the results of the query
				$stmt->fetch();

				$stmt->close();
			}
			else {
				//echo '<p class="error">Execute failed</p>';
				//echo '<p class="error">' . mysqli_error($db) . '</p>';
                                return FALSE;
			}
                }
			else
				echo '<p class="error">Could not connect to database</p>';
			return false;
	}

        public function getAll() {
		if($this->getDBConnection()){
                        $toReturn = Array();
                        /*$q = "SELECT Review_ID, Review, Review_Level, Review_Date, Review_Reply, Facility_ID, Review_Status,User_ID FROM Reviews where Facility_ID='".$Facility_ID."'";
echo $q."\n";*/
                        $sql = "SELECT * FROM Site_Category ;";
			//create the prepared statement
			$result = $this->dbc->query($sql);
                        /*$r = mysqli_query($this->dbc, $q);
                        if($r)
                        {
                        while ($row = mysqli_fetch_array($r)) {
                            $review = new DO_Reviews();
                            $review->get($row["Review_ID"]);
                            $toReturn[] = $row;
                        }*/
			if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                        $categ = new DO_Site_Category();
                                        $categ->get($row["Category_ID"]);
                                        $toReturn[] = $categ;
                                        
                                    }
                                    return $toReturn;
                                } else {
                                    echo '<script>alert("Error, No categories were found!");</script>';
                                    return FALSE;
                                }
                             
                        
                
                                
			}
                
			else
				echo '<p class="error">Could not connect to database</p>';
			return false;
	}
        
	public function save(){

		if ($this->getDBConnection()) {
			//guard against XSS
			$this->Category_Name = strip_tags($this->Category_Name);
			$this->Category_Description = strip_tags($this->Category_Description);
			//help prevent SQL injection by escaping any special characters using mysqli_real_escape_string function
			$this->Category_Name = mysqli_real_escape_string($this->dbc, $this->Category_Name);
			$this->Category_Description = mysqli_real_escape_string($this->dbc, $this->Category_Description);

			if ($this->Category_ID == null) {
				$q = "INSERT INTO Site_Category(Category_ID, Category_Name, Category_Description) values('', ?, ?)";
			} else {
				$q = "update Site_Category set Category_Name=?, Category_Description=?, where Category_ID=? ";
			}

			$stmt = $this->dbc->prepare($q);

			if ($stmt) {
				//code below is binding paramters to the statement
				if ($this->Category_ID == null){
					$stmt->bind_param('ss', $this->Category_Name, $this->Category_Description); 				} 
                                        else {
					$stmt->bind_param('sss', $this->Category_Name, $this->Category_Description, $this->Category_ID);
				}

				//execute the statement and then check the result
				if (! $stmt->execute()) {
					$this->displayError($q);
					return false;
				}
			} else {
				$this->displayError($q);
				return false;
			}
			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
		return true;
	}


	public function delete(){
		if($this->getDBConnection()){
			$q = "DELETE FROM Site_Category WHERE Category_ID=" . mysql_escape_string($this->Category_ID);

			$r = mysqli_query($this->dbc, $q);

			if(!$r){
				$this->displayError($q);
				return false;
			}

			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
	}


	public function isValid() {

		//declare array to hold any errors messages
		$errors = array();

		if (empty($this->Category_Name))
			$errors[] = 'You must enter Category_Name';
		if (empty($this->Category_Description))
			$errors[] = 'You must enter Category_Description';

		return $errors;
	}

	private function displayError($q){
		echo '<p class="error">A database error occurred - contact the admin</p>';
		//when this is a live system so we do not display too much information to the user so comment out the lines below
		//echo '<p class="error">' . $q . '</p>';
		//echo '<p class="error">' . mysqli_error($this->dbc) .'</p>';
	}

}
?>
