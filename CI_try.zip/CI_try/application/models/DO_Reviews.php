<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * This class was coded by sayed mohammed alnajjar 201301587
 * with help from the Data Object Emitter program
*/


class DO_Reviews extends mysqli_con {
        
        public $User_ID;
	public $Review_ID=null;
	public $Review;
	public $Review_Level=1;
	public $Review_Date;
	public $Review_Reply;
	public $Facility_ID;
	public $Review_Status;
	public $errorMsg;
	public $dbc=null;

	public function  __construct() /*DO_Reviews() depricated name*/ {
                
		$this->getDBConnection();
}

	private function getDBConnection() {
		//replace with your own connection class
		
		try{
			if($this->dbc == null){
				$db = new mysqli_con();
				$this->dbc = $db->getConnection();
			}
		return $this->dbc;
		}
		catch (Exception $e) {
			echo 'Caught exception: '.$e->getMessage();
			return null;
		}
	}
        public function getByFac($Facility_ID) {
		if($this->getDBConnection()){
                        $toReturn = Array();
                        /*$q = "SELECT Review_ID, Review, Review_Level, Review_Date, Review_Reply, Facility_ID, Review_Status,User_ID FROM Reviews where Facility_ID='".$Facility_ID."'";
echo $q."\n";*/
                        $sql = "SELECT Review_ID, Review, Review_Level, "
                                . "Review_Date, Review_Reply, Facility_ID, "
                                . "Review_Status,User_ID FROM Reviews where "
                                . "Facility_ID='".$Facility_ID."' AND Review_Level = 1 AND Review_Status = 'Active'";
			//create the prepared statement
			$result = $this->dbc->query($sql);
                        /*$r = mysqli_query($this->dbc, $q);
                        if($r)
                        {
                        while ($row = mysqli_fetch_array($r)) {
                            $review = new DO_Reviews();
                            $review->get($row["Review_ID"]);
                            $toReturn[] = $row;
                        }*/
			if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                        $Review = new DO_Reviews();
                                        $Review->get($row["Review_ID"]);
                                        $toReturn[] = $Review;
                                        
                                    }
                                    return $toReturn;
                                } else {
                                    echo '<script>alert("there are no comments, be the First!!");</script>';
                                    return FALSE;
                                }
                             
                        
                
                                
			}
                
			else
				echo '<p class="error">Could not connect to database</p>';
			return false;
	}
        public function AddReplies($Fac_ID,$reviewList)
        {
            $Level = 2;
            $moreReplies = TRUE;
            while($moreReplies)
            {
                
                $moreReplies = $this->getRepliesByReviewLevel($Fac_ID, $Level);
                if($moreReplies)
                {
                    
                    $reviewList = $this->addToReviews($reviewList, $moreReplies);
                    
                    
                }
                $Level++;
            }
            return $reviewList;
            
        }
        public function addToReviews($reviewList, $moreReplies)
        {
            /*$value = new DO_Reviews();
            $value->Review = "INSERTED AT LAST!!!!";
            array_splice($reviewList, 1, 0, $value);
            foreach ($reviewList as $key => $value) {
                echo $key."<br/>";
            }
            
            print_r($reviewList);
            print_r($moreReplies);*/
            
            
            
            
            
            if($moreReplies)
            {
                foreach ($moreReplies as $value) {
                    
                    $tofind = new DO_Reviews();
                    if($tofind->get($value->Review_Reply))
                    {
                        foreach ($reviewList as $key => $value2) {
                            //print_r($value2);
                            //echo '<hr>';
                            //print_r($value);
                            //echo '<br/><br/>';
                            //print_r($value2);
                            if($value2->Review_ID == $value->Review_Reply)
                            {
                                $index = $key;
                                $reviewList = $this->addAtPos($index,$reviewList,$value);
                            }
                        }
                        //$index = array_search($tofind, $reviewList);
                        //print_r($moreReplies);
                        //array_splice($reviewList, ($index + 1), 0, $value);
                        
                        
                    }
                    else
                    {
                        return FALSE;
                    }
                    
                    
                }
                return $reviewList;
            }
            else
            {
                return FALSE;
            }
        }
        /**
         * 
         * @param type $index  the current index key of the review to insert a reply for
         * @param type $reviewList  the list of reviews expected to get
         * @param type $value   the review to insert in the list of reviews
         * @return type $reviewList     the list of reviews expected to get after adding the replied review in it
         */
        public function addAtPos($index,$reviewList,$value) {
            $firstHalf = array_slice($reviewList, 0, $index+1);
            $secondHalf = array_slice($reviewList, $index+1);
            $returnedArray = Array();
            foreach ($firstHalf as $firstobjs) {
                $returnedArray[] = $firstobjs;
            }
            $returnedArray[] = $value;
            foreach ($secondHalf as $secondobjs) {
                $returnedArray[] = $secondobjs;
            }
            
            return $returnedArray;
        }
        public function getRepliesByReviewLevel($Fac_ID, $Level)
        {
            if($this->getDBConnection()){
                        $toReturn = Array();
                        /*$q = "SELECT Review_ID, Review, Review_Level, Review_Date, Review_Reply, Facility_ID, Review_Status,User_ID FROM Reviews where Facility_ID='".$Facility_ID."'";
echo $q."\n";*//*Review_ID, Review, Review_Level, "
                                . "Review_Date, Review_Reply, Facility_ID, "
                                . "Review_Status,User_ID*/
                        $sql = "SELECT * FROM Reviews where "
                                . "Facility_ID='".$Fac_ID."' AND Review_Level='$Level'";
			//create the prepared statement
			$result = $this->dbc->query($sql);
                        /*$r = mysqli_query($this->dbc, $q);
                        if($r)
                        {
                        while ($row = mysqli_fetch_array($r)) {
                            $review = new DO_Reviews();
                            $review->get($row["Review_ID"]);
                            $toReturn[] = $row;
                        }*/
			if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                        $Review = new DO_Reviews();
                                        $Review->get($row["Review_ID"]);
                                        $toReturn[] = $Review;
                                        
                                    }
                                    return $toReturn;
                                } else {
                                    //echo '<script>alert("there are no comments, be the First!!");</script>';
                                    return FALSE;
                                }
                             
                        
                
                                
			}
                
			else
				echo '<p class="error">Could not connect to database</p>';
			return false;
        }
        /*public function AddReplies($reviewList)
        {
            $replyExists = TRUE;
            foreach ($reviewList as $value) {
                $value = new DO_Reviews();
                
                while ($replyExists)
                {
                    
                    $q = "SELECT * FROM Reviews WHERE Review_Reply='$value->Review_ID'";
                    $r = mysqli_query($this->dbc, $q);
                    if($r)
                    {
                        if(mysqli_num_rows($r) == 0)
                        {
                            $replyExists = FALSE;
                        }
                        else
                        {
                            while ($row = mysql_fetch_array($r)) {
                                
                            }
                        }
                        
                         //* check for rows returned to find how many reviews retrieved 
                         //* if its more than 1 then we have a list to handle
                         //* if its one then just handle it
                         //* if none then exit loop
                         
                    }
                    else
                    {
                        $Error[] = "Database Error encountered";
                    }
                    
                }
                
            }
        }*/
        public function getBySearch($Search) {
		if($this->getDBConnection()){
                        $toReturn = Array();
                        /*$q = "SELECT Review_ID, Review, Review_Level, Review_Date, Review_Reply, Facility_ID, Review_Status,User_ID FROM Reviews where Facility_ID='".$Facility_ID."'";
echo $q."\n";*/
                        $sql = "SELECT * FROM Reviews WHERE MATCH (Review)
                                AGAINST ('$Search' IN BOOLEAN MODE);";
			//create the prepared statement
			$result = $this->dbc->query($sql);
                        /*$r = mysqli_query($this->dbc, $q);
                        if($r)
                        {
                        while ($row = mysqli_fetch_array($r)) {
                            $review = new DO_Reviews();
                            $review->get($row["Review_ID"]);
                            $toReturn[] = $row;
                        }*/
			if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                        $Review = new DO_Reviews();
                                        $Review->get($row["Review_ID"]);
                                        $toReturn[] = $Review;
                                        
                                    }
                                    return $toReturn;
                                } else {
                                    echo '<script>alert("there were no reviews '
                                    . 'found");</script>';
                                    return FALSE;
                                }
                             
                        
                
                                
			}
                
			else
				echo '<p class="error">Could not connect to data'
                            . 'base</p>';
			return false;
	}
	public function get($Review_ID) {
		if($this->getDBConnection()){
			$q = "SELECT Review_ID, Review, Review_Level, Review_Dat"
                                . "e, Review_Reply, Facility_ID, Review_Status,"
                                . "User_ID FROM Reviews where Review_ID=".$Review_ID;
			//create the prepared statement
			$stmt = $this->dbc->prepare($q);

			//bind the variables to the statement
			//$stmt->bind_param('s', $Review_ID);

			//execute the statement
			if ($stmt) {
                            $return = TRUE;
                            $stmt->execute();
				/* store result */
				$stmt->store_result();
                                
                                if($stmt->num_rows == 0){
                                    $return = FALSE;
                                    
                                }
                                
				//bind the output results to the members of the class
				$stmt->bind_result($this->Review_ID, $this->Review,
                                        $this->Review_Level, $this->Review_Date,
                                        $this->Review_Reply, $this->Facility_ID,
                                        $this->Review_Status, $this->User_ID);
                                
				//get the results of the query
				$stmt->fetch();

				$stmt->close();
                                return $return;
			}
			else {
				//echo '<p class="error">Execute failed</p>';
				//echo '<p class="error">' . mysqli_error($this->dbc) . '</p>';
                                return FALSE;
			}
                }
			else
				echo '<p class="error">Could not connect to database</p>';
			return false;
	}
        


	public function save(){

		if ($this->getDBConnection()) {
			//guard against XSS
			//$this->Review = strip_tags($this->Review);
			$this->Review_Level = strip_tags($this->Review_Level);
			$this->Review_Reply = strip_tags($this->Review_Reply);
			$this->Facility_ID = strip_tags($this->Facility_ID);
			$this->Review_Status = strip_tags($this->Review_Status);
                        $this->User_ID = strip_tags($this->User_ID);
			//help prevent SQL injection by escaping any special characters using mysqli_real_escape_string function
			//$this->Review = mysqli_real_escape_string($this->dbc, $this->Review);
			$this->Review_Level = mysqli_real_escape_string($this->dbc, $this->Review_Level);
			$this->Review_Reply = mysqli_real_escape_string($this->dbc, $this->Review_Reply);
			$this->Facility_ID = mysqli_real_escape_string($this->dbc, $this->Facility_ID);
			$this->Review_Status = mysqli_real_escape_string($this->dbc, $this->Review_Status);
                        $this->User_ID = mysqli_real_escape_string($this->dbc, $this->User_ID);

			if ($this->Review_ID == null) {
				$q = "INSERT INTO Reviews(Review_ID, Review, Review_Level, Review_Date, Review_Reply, Facility_ID, Review_Status, User_ID) values(null, ?, ?, NOW(), ?, ?, ?, ?)";
			} else {
				$q = "update Reviews set Review=?, Review_Level=?, Review_Reply=?, Facility_ID=?, Review_Status=?, User_ID=? where `Review_ID`='$this->Review_ID' ";
			}

			$stmt = $this->dbc->prepare($q);

			if ($stmt) {
				//code below is binding paramters to the statement
				if ($this->Review_ID == null){
					$stmt->bind_param('sissss', $this->Review, $this->Review_Level, $this->Review_Reply, $this->Facility_ID, $this->Review_Status, $this->User_ID); 				} else {
					$stmt->bind_param('sissss', $this->Review, $this->Review_Level, $this->Review_Reply, $this->Facility_ID, $this->Review_Status, $this->User_ID);
                                        }

				//execute the statement and then check the result
				if (! $stmt->execute()) {
					//$this->displayError($q);
					return false;
				}
			} else {
				//$this->displayError($q);
				return false;
			}
			return true;
		} else {
			//echo '<p class="error">Could not connect to database</p>';
			return false;
		}
		return true;
	}


	public function delete(){
		if($this->getDBConnection()){
			$q = "DELETE FROM Reviews WHERE Review_ID=" . mysqli_real_escape_string($this->dbc,$this->Review_ID);
                        
			$r = mysqli_query($this->dbc, $q);

			if(!$r){
				$this->displayError($q);
				return false;
			}

			return true;
		} else {
			//echo '<p class="error">Could not connect to database</p>';
			return false;
		}
	}


	public function isValid() {

		//declare array to hold any errors messages
		$errors = array();

		if (empty($this->Review))
			$errors[] = 'You must enter Review';
		if (empty($this->Review_Level))
			$errors[] = 'You must enter Review_Level';
		if (empty($this->Review_Reply))
			$errors[] = 'You must enter Review_Reply';
		if (empty($this->Facility_ID))
			$errors[] = 'You must enter Facility_ID';
		if (empty($this->Review_Status))
			$errors[] = 'You must enter Review_Status';
                if (empty($this->User_ID))
                        $errors[] = 'You must enter User_ID';

		return $errors;
	}

	private function displayError($q){
		echo '<p class="error">A database error occurred - contact the admin</p>';
		//when this is a live system so we do not display too much information to the user so comment out the lines below
		//echo '<p class="error">' . $q . '</p>';
		//echo '<p class="error">' . mysqli_error($this->dbc) .'</p>';
	}

}
?>
