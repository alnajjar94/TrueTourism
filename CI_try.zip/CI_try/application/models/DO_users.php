<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 

 * This class was coded by sayed mohammed alnajjar 201301587
 * with help from the Data Object Emitter program
*/

class DO_users extends mysqli_con {

	public $User_ID=null;
	public $User_Picture = "Pic/Superman_avatar.jpg";
	public $User_Role= "user";
	public $User_Name= null;
	public $User_Email= null;
	public $User_NickName= null;
	public $User_Password= null;
	public $User_Verified= null;
	public $User_Verification_Num= null;
	public $errorMsg= null;
	public $dbc=null;

	public function  __construct() /*DO_users() depricated name*/ {

		$this->getDBConnection();
}

	private function getDBConnection() {
		//replace with your own connection class
		
		try{
			if($this->dbc == null){
				$db = new mysqli_con();
				$this->dbc = $db->getConnection();
			}
		return $this->dbc;
		}
		catch (Exception $e) {
			echo 'Caught exception: '.$e->getMessage();
			return null;
		}
	}

        public function getUser($NickName) {
		if($this->getDBConnection()){
                        $return =TRUE;
			$q = "SELECT User_ID, User_Picture, User_Role, User_Name, User_Email, User_NickName, User_Password, User_Verified, User_Verification_Num FROM users where User_NickName='".$NickName."'";
			//create the prepared statement
			$stmt = $this->dbc->prepare($q);
                        //echo "<script>alert(\"".mysqli_error($this->dbc)."\");</script>";
			//bind the variables to the statement
                        
			//execute the statement
			if ($stmt->execute()) {

				/* store result */
				$stmt->store_result();
                                if($stmt->num_rows == 0){
                                    $return = FALSE;
                                    
                                }
				//bind the output results to the members of the class
				$stmt->bind_result($this->User_ID, $this->User_Picture, $this->User_Role, $this->User_Name, $this->User_Email, $this->User_NickName, $this->User_Password, $this->User_Verified, $this->User_Verification_Num);
                                
				//get the results of the query
				$stmt->fetch();
                                
				$stmt->close();
                                return $return;
			}
			else {
				//echo '<p class="error">Execute failed</p>';
				//echo '<p class="error">' . mysqli_error($this->dbc) . '</p>';
                                return FALSE;
			}
                }
			else{
				//echo '<p class="error">Could not connect to database</p>';
                        return false;}
	}
        
        public function getAll() {
		if($this->getDBConnection()){
                        $toReturn = Array();
                        /*$q = "SELECT Review_ID, Review, Review_Level, Review_Date, Review_Reply, Facility_ID, Review_Status,User_ID FROM Reviews where Facility_ID='".$Facility_ID."'";
echo $q."\n";*/
                        $sql = "SELECT * FROM users;";
			//create the prepared statement
			$result = $this->dbc->query($sql);
                        /*$r = mysqli_query($this->dbc, $q);
                        if($r)
                        {
                        while ($row = mysqli_fetch_array($r)) {
                            $review = new DO_Reviews();
                            $review->get($row["Review_ID"]);
                            $toReturn[] = $row;
                        }*/
			if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                        $user = new DO_users();
                                        $user->get($row["User_ID"]);
                                        $toReturn[] = $user;
                                        
                                    }
                                    return $toReturn;
                                } else {
                                    echo '<script>alert("Error, No Sites were found!");</script>';
                                    return FALSE;
                                }
                             
                        
                
                                
			}
                
			else
				echo '<p class="error">Could not connect to database</p>';
			return false;
	}
        
        
        
	public function get($User_ID) {
		if($this->getDBConnection()){
			$q = "SELECT User_ID, User_Picture, User_Role, User_Name, User_Email, User_NickName, User_Password, User_Verified, User_Verification_Num FROM users where User_ID=".$User_ID;
			//create the prepared statement
			$stmt = $this->dbc->prepare($q);
                        
			//bind the variables to the statement
                        
			//execute the statement
			if ($stmt) {
                            try {
                                $return = TRUE;
                            
                                $stmt->execute();
				/* store result */
				$stmt->store_result();
                                if($stmt->num_rows == 0){
                                    $return = FALSE;
                                    
                                }
				//bind the output results to the members of the class
				$stmt->bind_result($this->User_ID, $this->User_Picture, $this->User_Role, $this->User_Name, $this->User_Email, $this->User_NickName, $this->User_Password, $this->User_Verified, $this->User_Verification_Num);

				//get the results of the query
				$stmt->fetch();

				$stmt->close();
                                
                                return $return;
                                } catch (Exception $ex) {
                                    echo $ex->getMessage();
                                    return FALSE;
                            }
			}
			else {
				$Error[] = 'Execute failed';
				//echo '<p class="error">' . mysqli_error($db) . '</p>';
                                return FALSE;
			}
                }
			else{
				$Error[] = 'Could not connect to database';
                        return false;}
                        return false;
	}


	public function save(){

		if ($this->getDBConnection()) {
			//guard against XSS
			$this->User_Picture = strip_tags($this->User_Picture);
			$this->User_Role = strip_tags($this->User_Role);
			$this->User_Name = strip_tags($this->User_Name);
			$this->User_Email = strip_tags($this->User_Email);
			$this->User_NickName = strip_tags($this->User_NickName);
			$this->User_Password = strip_tags($this->User_Password);
			$this->User_Verified = strip_tags($this->User_Verified);
			$this->User_Verification_Num = strip_tags($this->User_Verification_Num);
			//help prevent SQL injection by escaping any special characters using mysqli_real_escape_string function
			$this->User_Picture = mysqli_real_escape_string($this->dbc, $this->User_Picture);
			$this->User_Role = mysqli_real_escape_string($this->dbc, $this->User_Role);
			$this->User_Name = mysqli_real_escape_string($this->dbc, $this->User_Name);
			$this->User_Email = mysqli_real_escape_string($this->dbc, $this->User_Email);
			$this->User_NickName = mysqli_real_escape_string($this->dbc, $this->User_NickName);
			$this->User_Password = mysqli_real_escape_string($this->dbc, $this->User_Password);
			$this->User_Verified = mysqli_real_escape_string($this->dbc, $this->User_Verified);
			$this->User_Verification_Num = mysqli_real_escape_string($this->dbc, $this->User_Verification_Num);

			if ($this->User_ID == null) {
				$q = "INSERT INTO users( User_Picture, User_Role, User_Name, User_Email, User_NickName, User_Password, User_Verified, User_Verification_Num) values( ?, ?, ?, ?, ?, ?, ?, ?)";
			} else {
				$q = "update users set User_Picture=?, User_Role=?, User_Name=?, User_Email=?, User_Password=?, User_Verified=?, User_Verification_Num=? where User_ID=$this->User_ID ";
			}

			$stmt = $this->dbc->prepare($q);
                        //print_r($this);
			if ($stmt) {
				//code below is binding paramters to the statement
                            $null = NULL;
				if ($this->User_ID == null){
					$stmt->bind_param('bsssssss', $null, $this->User_Role, $this->User_Name, $this->User_Email, $this->User_NickName, $this->User_Password, $this->User_Verified, $this->User_Verification_Num);
                                        $stmt->send_long_data(0, file_get_contents($this->User_Picture));
                                        } else {
                                            
					$stmt->bind_param('bssssss', $null, $this->User_Role, $this->User_Name, $this->User_Email, $this->User_Password, $this->User_Verified, $this->User_Verification_Num);
                                            $stmt->send_long_data(0, file_get_contents($this->User_Picture));
				}

				//execute the statement and then check the result
    
				if (! $stmt->execute()) {
                                        
                                        
					$this->displayError($q);
					return false;
				}
			} else {
				$this->displayError($q);
				return false;
			}
			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
		return true;
	}


	public function delete(){
		if($this->getDBConnection()){
			$q = "DELETE FROM users WHERE User_ID=" . mysql_escape_string($this->dbc, $this->User_ID);

			$r = mysqli_query($this->dbc, $q);

			if(!$r){
				//$this->displayError($q);
				return false;
			}

			return true;
		} else {
			//echo '<p class="error">Could not connect to database</p>';
			return false;
		}
	}


	public function isValid() {

		//declare array to hold any errors messages
		$errors = array();

		if (empty($this->User_Picture))
			$errors[] = 'You must enter User_Picture';
		if (empty($this->User_Role))
			$errors[] = 'You must enter User_Role';
		if (empty($this->User_Name))
			$errors[] = 'You must enter User_Name';
		if (empty($this->User_Email))
			$errors[] = 'You must enter User_Email';
		if (empty($this->User_NickName))
			$errors[] = 'You must enter User_NickName';
		if (empty($this->User_Password))
			$errors[] = 'You must enter User_Password';
		if (empty($this->User_Verified))
			$errors[] = 'You must enter User_Verified';
		if (empty($this->User_Verification_Num))
			$errors[] = 'You must enter User_Verification_Num';

		return $errors;
	}

	private function displayError($q){
		echo '<p class="error">A database error occurred - contact the admin</p>';
		//when this is a live system so we do not display too much information to the user so comment out the lines below
		//echo '<p class="error">' . $q . '</p>';
		//echo '<p class="error">' . mysqli_error($this->dbc) .'</p>';
	}

}
?>
