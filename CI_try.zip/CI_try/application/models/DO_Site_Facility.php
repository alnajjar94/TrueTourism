<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * This class was coded by sayed mohammed alnajjar 201301587
 * with help from the Data Object Emitter program
*/


class DO_Site_Facility extends mysqli_con {

	public $Facility_ID=null;
	public $Facility_Name;
	public $Site_ID;
	public $Facility_Description;
	public $Facility_Picture;
	public $errorMsg;
	public $dbc=null;

	public function  __construct() /*DO_Site_Facility() depricated name*/ {

		$this->getDBConnection();
}

	private function getDBConnection() {
		//replace with your own connection class
		include_once "application/models/mysqli_con.php";
		try{
			if($this->dbc == null){
				$db = new mysqli_con();
				$this->dbc = $db->getConnection();
			}
		return $this->dbc;
		}
		catch (Exception $e) {
			echo 'Caught exception: '.$e->getMessage();
			return null;
		}
	}


	public function get($Facility_ID) {
		if($this->getDBConnection()){
			$q = "SELECT Facility_ID, Facility_Name, Site_ID, Facility_Description, Facility_Picture FROM Site_Facility where Facility_ID=".$Facility_ID;

			//create the prepared statement
			$stmt = $this->dbc->prepare($q);
			//bind the variables to the statement
			//$stmt->bind_param('s', $Facility_ID);
                        
			//execute the statement
			if ($stmt) {
                            $stmt->execute();
				/* store result */
				$stmt->store_result();

				//bind the output results to the members of the class
				$stmt->bind_result($this->Facility_ID, $this->Facility_Name, $this->Site_ID, $this->Facility_Description, $this->Facility_Picture);

				//get the results of the query
				$stmt->fetch();

				$stmt->close();
			}
			else {
				//echo '<p class="error">Execute failed</p>';
				//echo '<p class="error">' . mysqli_error($db) . '</p>';
			}
                }
			else
				//echo '<p class="error">Could not connect to database</p>';
			return false;
	}
        
        public function getBySearch($Search) {
		if($this->getDBConnection()){
                        $toReturn = Array();
                        /*$q = "SELECT Review_ID, Review, Review_Level, Review_Date, Review_Reply, Facility_ID, Review_Status,User_ID FROM Reviews where Facility_ID='".$Facility_ID."'";
echo $q."\n";*/
                        $sql = "SELECT * FROM Site_Facility WHERE MATCH (Facility_Name,Facility_Description)
     AGAINST ('$Search' IN BOOLEAN MODE);";
			//create the prepared statement
			$result = $this->dbc->query($sql);
                        /*$r = mysqli_query($this->dbc, $q);
                        if($r)
                        {
                        while ($row = mysqli_fetch_array($r)) {
                            $review = new DO_Reviews();
                            $review->get($row["Review_ID"]);
                            $toReturn[] = $row;
                        }*/
			if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                        $Facility = new DO_Site_Facility();
                                        $Facility->get($row["Facility_ID"]);
                                        $toReturn[] = $Facility;
                                        
                                    }
                                    return $toReturn;
                                } else {
                                    echo '<script>alert("there were no facilities '
                                    . 'found");</script>';
                                    return FALSE;
                                }
                             
                        
                
                                
			}
        }
        
        
        public function getBySite($Site_ID)
        {
            
		if($this->getDBConnection()){
                        $toReturn = Array();
                        /*$q = "SELECT Review_ID, Review, Review_Level, Review_Date, Review_Reply, Facility_ID, Review_Status,User_ID FROM Reviews where Facility_ID='".$Facility_ID."'";
echo $q."\n";*/
                        $sql = "SELECT * FROM Site_Facility WHERE Site_ID = $Site_ID;";
			//create the prepared statement
			$result = $this->dbc->query($sql);
                        /*$r = mysqli_query($this->dbc, $q);
                        if($r)
                        {
                        while ($row = mysqli_fetch_array($r)) {
                            $review = new DO_Reviews();
                            $review->get($row["Review_ID"]);
                            $toReturn[] = $row;
                        }*/
			if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                        $facility = new DO_Site_Facility();
                                        
                                        $facility->get($row["Facility_ID"]);
                                        $toReturn[] = $facility;
                                        
                                    }
                                    return $toReturn;
                                } else {
                                    
                                    return FALSE;
                                }
                             
                        
                
                                
			}
                
			else
				echo '<p class="error">Could not connect to database</p>';
			return false;
        }
        
        
        
        
        
	public function save(){

		if ($this->getDBConnection()) {
			//guard against XSS
			$this->Facility_Name = strip_tags($this->Facility_Name);
			$this->Site_ID = strip_tags($this->Site_ID);
			$this->Facility_Description = strip_tags($this->Facility_Description);
			//$this->Facility_Picture = strip_tags($this->Facility_Picture);
			//help prevent SQL injection by escaping any special characters using mysqli_real_escape_string function
			$this->Facility_Name = mysqli_real_escape_string($this->dbc, $this->Facility_Name);
			$this->Site_ID = mysqli_real_escape_string($this->dbc, $this->Site_ID);
			$this->Facility_Description = mysqli_real_escape_string($this->dbc, $this->Facility_Description);
			//$this->Facility_Picture = mysqli_real_escape_string($this->dbc, $this->Facility_Picture);

			if ($this->Facility_ID == null) {
				$q = "INSERT INTO Site_Facility(Facility_Name, Site_ID, Facility_Description, Facility_Picture) values(?, ?, ?, ?)";
			} else {
				$q = "update Site_Facility set Facility_Name=?, Site_ID=?, Facility_Description=?, Facility_Picture=?, where Facility_ID=? ";
			}

			$stmt = $this->dbc->prepare($q);
                        $null = NULL;


                        
			if ($stmt) {
				//code below is binding paramters to the statement
				if ($this->Facility_ID == null){
					$stmt->bind_param('sssb', $this->Facility_Name, $this->Site_ID, $this->Facility_Description, $null);
                                        $stmt->send_long_data(3, file_get_contents($this->Facility_Picture));
                                        
                                } else {
					$stmt->bind_param('sssbs', $this->Facility_Name, $this->Site_ID, $this->Facility_Description, $this->Facility_Picture, $this->Facility_ID);
				}

				//execute the statement and then check the result
				if (! $stmt->execute()) {
					$this->displayError($q);
					return false;
				}
                                echo 'EXECUTED!';
			} else {
				$this->displayError($q);
				return false;
			}
			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
		return true;
	}


	public function delete(){
		if($this->getDBConnection()){
			$q = "DELETE FROM Site_Facility WHERE Facility_ID=" . mysql_escape_string($this->Facility_ID);

			$r = mysqli_query($this->dbc, $q);

			if(!$r){
				$this->displayError($q);
				return false;
			}

			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
	}


	public function isValid() {

		//declare array to hold any errors messages
		$errors = array();

		if (empty($this->Facility_Name))
			$errors[] = 'You must enter Facility_Name';
		if (empty($this->Site_ID))
			$errors[] = 'You must enter Site_ID';
		if (empty($this->Facility_Description))
			$errors[] = 'You must enter Facility_Description';
		if (empty($this->Facility_Picture))
			$errors[] = 'You must enter Facility_Picture';

		return $errors;
	}

	private function displayError($q){
		echo '<p class="error">A database error occurred - contact the admin</p>';
		//when this is a live system so we do not display too much information to the user so comment out the lines below
		//echo '<p class="error">' . $q . '</p>';
		//echo '<p class="error">' . mysqli_error($this->dbc) .'</p>';
	}

}
?>
