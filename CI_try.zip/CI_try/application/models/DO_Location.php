<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * This class was coded by sayed mohammed alnajjar 201301587
 * with help from the Data Object Emitter program
*/

class DO_Location extends mysqli_con {

	public $Location_ID=null;
	public $Location_Name;
	public $Longtitude;
	public $Latitude;
	public $errorMsg;
	public $dbc=null;

	public function  __construct() /*DO_Location() depricated name*/ {

		$this->getDBConnection();
}

	private function getDBConnection() {
		//replace with your own connection class
		include_once "mysqli_con.php";
		try{
			if($this->dbc == null){
				$db = new mysqli_con();
				$this->dbc = $db->getConnection();
			}
		return $this->dbc;
		}
		catch (Exception $e) {
			echo 'Caught exception: '.$e->getMessage();
			return null;
		}
	}


	public function get($Location_ID) {
		if($this->getDBConnection()){
			$q = "SELECT Location_ID, Location_Name, Longtitude, Latitude FROM Location where Location_ID=".$Location_ID;
			//create the prepared statement
			$stmt = $this->dbc->prepare($q);

			//bind the variables to the statement
			$stmt->bind_param('s', $Location_ID);

			//execute the statement
			if ($stmt->execute()) {

				/* store result */
				$stmt->store_result();

				//bind the output results to the members of the class
				$stmt->bind_result($this->Location_ID, $this->Location_Name, $this->Longtitude, $this->Latitude);

				//get the results of the query
				$stmt->fetch();

				$stmt->close();
			}
			else {
				echo '<p class="error">Execute failed</p>';
				//echo '<p class="error">' . mysqli_error($db) . '</p>';
			}
			
                }
	}
        public function getByName($Location_Name) {
		if($this->getDBConnection()){
			$q = "SELECT Location_ID, Location_Name, Longtitude, Latitude FROM Location where Location_Name like '".$Location_Name."';";
			//create the prepared statement
                        
			//$stmt = $this->dbc->prepare($q);
			//bind the variables to the statement
			//$stmt->bind_param('s', $Location_Name);
                        
                        $r = mysqli_query($this->dbc, $q);
                        
			//execute the statement
			if ($r) {
                            
                            $row = mysqli_fetch_array($r);
                            
                            $this->Location_ID = $row["Location_ID"];
                            $this->Location_Name = $row["Location_Name"];
                            $this->Longtitude = $row["Longtitude"];
                            $this->Latitude = $row["Latitude"];
                            
                            
				/* store result */
				//$stmt->store_result();

				//bind the output results to the members of the class
				//$stmt->bind_result($this->Location_ID, $this->Location_Name, $this->Longtitude, $this->Latitude);
                                
				//get the results of the query
				//$stmt->fetch();

				//$stmt->close();
			}
			else {
				echo '<p class="error">location retrieval failed</p>';
				//echo '<p class="error">Database'. mysqli_error($this->dbc).' error</p>';
			}
			
                }
	}


	public function save(){

		if ($this->getDBConnection()) {
			//guard against XSS
			$this->Location_Name = strip_tags($this->Location_Name);
			$this->Longtitude = strip_tags($this->Longtitude);
			$this->Latitude = strip_tags($this->Latitude);
			//help prevent SQL injection by escaping any special characters using mysqli_real_escape_string function
			$this->Location_Name = mysqli_real_escape_string($this->dbc, $this->Location_Name);
			$this->Longtitude = mysqli_real_escape_string($this->dbc, $this->Longtitude);
			$this->Latitude = mysqli_real_escape_string($this->dbc, $this->Latitude);

			if ($this->Location_ID == null) {
				$q = "INSERT INTO Location(Location_Name, Longtitude, Latitude) values( ?, ?, ?)";
			} else {
				$q = "update Location set Location_Name=?, Longtitude=?, Latitude=?, where Location_ID=? ";
			}

			$stmt = $this->dbc->prepare($q);

			if ($stmt) {
				//code below is binding paramters to the statement
				if ($this->Location_ID == null){
					$stmt->bind_param('sdd', $this->Location_Name, $this->Longtitude, $this->Latitude); 				} else {
					$stmt->bind_param('sdds', $this->Location_Name, $this->Longtitude,$this->Latitude ,$this->Location_ID);
				}

				//execute the statement and then check the result
				if (! $stmt->execute()) {
					$this->displayError($q);
					return false;
				}
			} else {
				$this->displayError($q);
				return false;
			}
			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
		return true;
	}


	public function delete(){
		if($this->getDBConnection()){
			$q = "DELETE FROM Location WHERE Location_ID=" . mysql_escape_string($this->Location_ID);

			$r = mysqli_query($this->dbc, $q);

			if(!$r){
				$this->displayError($q);
				return false;
			}

			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
	}


	public function isValid() {

		//declare array to hold any errors messages
		$errors = array();

		if (empty($this->Location_Name))
			$errors[] = 'You must enter Location_Name';
		if (empty($this->Longtitude))
			$errors[] = 'You must enter Longtitude';
		if (empty($this->Latitude))
			$errors[] = 'You must enter Latitude';

		return $errors;
	}

	private function displayError($q){
		echo '<p class="error">A database error occurred - contact the admin</p>';
		//when this is a live system so we do not display too much information to the user so comment out the lines below
		//echo '<p class="error">' . $q . '</p>';
		//echo '<p class="error">' . mysqli_error($this->dbc) .'</p>';
	}

}
?>
