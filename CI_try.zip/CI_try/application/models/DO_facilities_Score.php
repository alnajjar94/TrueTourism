<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * This class was coded by sayed mohammed alnajjar 201301587
 * with help from the Data Object Emitter program
*/


class DO_facilities_Score extends mysqli_con {

	public $Score_ID=null;
	public $Facility_ID;
	public $Score;
	public $User_ID;
	public $errorMsg;
	public $dbc=null;

	public function  __construct() /*DO_facilities_Score() depricated name*/ {
                
		$this->getDBConnection();
}

	private function getDBConnection() {
		//replace with your own connection class
		//include_once "mysqli_connect.php";
		try{
			if($this->dbc == null){
				$db = new mysqli_con();
				$this->dbc = $db->getConnection();
			}
		return $this->dbc;
		}
		catch (Exception $e) {
			//echo 'Caught exception: '.$e->getMessage();
			return null;
		}
	}


	public function get($Score_ID) {
		if($this->getDBConnection()){
			$q = "SELECT Score_ID, Facility_ID, Score, User_ID FROM facilities_Score where Score_ID=".$Score_ID;
			//create the prepared statement
			$stmt = $this->dbc->prepare($q);

			//bind the variables to the statement

			//execute the statement
			if ($stmt) {
                                $stmt->execute();
				/* store result */
				$stmt->store_result();

				//bind the output results to the members of the class
				$stmt->bind_result($this->Score_ID, $this->Facility_ID, $this->Score, $this->User_ID);

				//get the results of the query
				$stmt->fetch();

				$stmt->close();
			}
			else {
				//echo '<p class="error">Execute failed</p>';
				//echo '<p class="error">' . mysqli_error($db) . '</p>';
                                return False;
                        }
			}
			else{
				//echo '<p class="error">Could not connect to database</p>';
                        return false;
                        
                        }
	}


	public function save(){

		if ($this->getDBConnection()) {
			//guard against XSS
			$this->Facility_ID = strip_tags($this->Facility_ID);
			$this->Score = strip_tags($this->Score);
			$this->User_ID = strip_tags($this->User_ID);
			//help prevent SQL injection by escaping any special characters using mysqli_real_escape_string function
			$this->Facility_ID = mysqli_real_escape_string($this->dbc, $this->Facility_ID);
			$this->Score = mysqli_real_escape_string($this->dbc, $this->Score);
			$this->User_ID = mysqli_real_escape_string($this->dbc, $this->User_ID);

			if ($this->Score_ID == null) {
				$q = "INSERT INTO facilities_Score(Facility_ID, Score, User_ID) values(?, ?, ?)";
			} else {
				$q = "update facilities_Score set Facility_ID=?, Score=?, User_ID=?, where Score_ID=$this->Score_ID ";
			}

			$stmt = $this->dbc->prepare($q);

			if ($stmt) {
				//code below is binding paramters to the statement
				if ($this->Score_ID == null){
					$stmt->bind_param('sdi', $this->Facility_ID, $this->Score, $this->User_ID);
                                                } else {
					$stmt->bind_param('sdii', $this->Facility_ID, $this->Score, $this->Score_ID);
				}

				//execute the statement and then check the result
				if (! $stmt->execute()) {
					//$this->displayError($q);
					return false;
				}
                                
			} else {
				//$this->displayError($q);
				return false;
			}
			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
		return true;
	}


	public function delete(){
		if($this->getDBConnection()){
			$q = "DELETE FROM facilities_Score WHERE Score_ID=" . mysql_escape_string($this->Score_ID);

			$r = mysqli_query($this->dbc, $q);

			if(!$r){
				$this->displayError($q);
				return false;
			}

			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
	}


	public function isValid() {

		//declare array to hold any errors messages
		$errors = array();

		if (empty($this->Facility_ID))
			$errors[] = 'You must enter Facility_ID';
		if (empty($this->Score))
			$errors[] = 'You must enter Score';
		if (empty($this->User_ID))
			$errors[] = 'You must enter User_ID';

		return $errors;
	}

	private function displayError($q){
		echo '<p class="error">A database error occurred - contact the admin</p>';
		//when this is a live system so we do not display too much information to the user so comment out the lines below
		//echo '<p class="error">' . $q . '</p>';
		//echo '<p class="error">' . mysqli_error($this->dbc) .'</p>';
	}

}
?>
