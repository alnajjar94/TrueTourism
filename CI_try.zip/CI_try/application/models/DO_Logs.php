<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * This class was coded by sayed mohammed alnajjar 201301587
 * with help from the Data Object Emitter program
*/

class DO_Logs extends mysqli_con {

	public $Log_ID=null;
	public $Logged_Action;
	public $User_ID;
	public $Log_Date;
	public $Log_Message;
	public $errorMsg;
	public $dbc=null;

	public function  __construct() /*DO_Logs() depricated name*/ {
                
		$this->getDBConnection();
}

	private function getDBConnection() {
		//replace with your own connection class
		//include_once "mysqli_connect.php";
		try{
			if($this->dbc == null){
				$db = new mysqli_con();
				$this->dbc = $db->getConnection();
			}
		return $this->dbc;
		}
		catch (Exception $e) {
			echo 'Caught exception: '.$e->getMessage();
			return null;
		}
	}


	public function get($Log_ID) {
		if($this->getDBConnection()){
			$q = "SELECT Log_ID, Logged_Action, User_ID, Log_Date, Log_Message FROM Logs where Log_ID=?";//.$Log_ID;
			//create the prepared statement
			$stmt = $this->dbc->prepare($q);

			//bind the variables to the statement
			$stmt->bind_param('s', $Log_ID);

			//execute the statement
			if ($stmt->execute()) {

				/* store result */
				$stmt->store_result();

				//bind the output results to the members of the class
				$stmt->bind_result($this->Log_ID, $this->Logged_Action, $this->User_ID, $this->Log_Date, $this->Log_Message);

				//get the results of the query
				$stmt->fetch();

				$stmt->close();
			}
			else {
				echo '<p class="error">Execute failed</p>';
				//echo '<p class="error">' . mysqli_error($db) . '</p>';
			}
                }
			else{
				echo '<p class="error">Could not connect to database</p>';
			return false;
                        }
	}
        public function getAll() {
		if($this->getDBConnection()){
                        $toReturn = Array();
                        /*$q = "SELECT Review_ID, Review, Review_Level, Review_Date, Review_Reply, Facility_ID, Review_Status,User_ID FROM Reviews where Facility_ID='".$Facility_ID."'";
echo $q."\n";*/
                        $sql = "SELECT * FROM Logs Order By Log_Date DESC;";
			//create the prepared statement
			$result = $this->dbc->query($sql);
                        /*$r = mysqli_query($this->dbc, $q);
                        if($r)
                        {
                        while ($row = mysqli_fetch_array($r)) {
                            $review = new DO_Reviews();
                            $review->get($row["Review_ID"]);
                            $toReturn[] = $row;
                        }*/
			if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                        $log = new DO_Logs();
                                        $log->get($row["Log_ID"]);
                                        $toReturn[] = $log;
                                        
                                    }
                                    return $toReturn;
                                } else {
                                    //echo '<script>alert("Error, No Sites were found!");</script>';
                                    return FALSE;
                                }
                             
                        
                
                                
			}
                
			else
				echo '<p class="error">Could not connect to database</p>';
			return false;
	}

	public function save(){

		if ($this->getDBConnection()) {
			//guard against XSS
			$this->Logged_Action = strip_tags($this->Logged_Action);
			$this->User_ID = strip_tags($this->User_ID);
			$this->Log_Message = strip_tags($this->Log_Message);
			//help prevent SQL injection by escaping any special characters using mysqli_real_escape_string function
			$this->Logged_Action = mysqli_real_escape_string($this->dbc, $this->Logged_Action);
			$this->User_ID = mysqli_real_escape_string($this->dbc, $this->User_ID);
			$this->Log_Message = mysqli_real_escape_string($this->dbc, $this->Log_Message);

			if ($this->Log_ID == null) {
				$q = "INSERT INTO Logs( Logged_Action, User_ID, Log_Date, Log_Message) values( ?, ?, NOW(), ?)";
			} else {
				$q = "update Logs set Logged_Action=?, User_ID=?, Log_Message=?, where Log_ID=? ";
			}

			$stmt = $this->dbc->prepare($q);

			if ($stmt) {
				//code below is binding paramters to the statement
				if ($this->Log_ID == null){
					$stmt->bind_param('sss', $this->Logged_Action, $this->User_ID, $this->Log_Message);
                                                
                                } 
                                else {
					$stmt->bind_param('ssss', $this->Logged_Action, $this->User_ID, $this->Log_ID);
				}

				//execute the statement and then check the result
				if (! $stmt->execute()) {
					$this->displayError($q);
					return false;
				}
			} else {
				$this->displayError($q);
				return false;
			}
			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
		return true;
	}


	public function delete(){
		if($this->getDBConnection()){
			$q = "DELETE FROM Logs WHERE Log_ID=" . mysql_escape_string($this->Log_ID);

			$r = mysqli_query($this->dbc, $q);

			if(!$r){
				$this->displayError($q);
				return false;
			}

			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
	}


	public function isValid() {

		//declare array to hold any errors messages
		$errors = array();

		if (empty($this->Logged_Action))
			$errors[] = 'You must enter Logged_Action';
		if (empty($this->User_ID))
			$errors[] = 'You must enter User_ID';
		if (empty($this->Log_Message))
			$errors[] = 'You must enter Log_Message';

		return $errors;
	}

	private function displayError($q){
		echo '<p class="error">A database error occurred - contact the admin</p>';
		//when this is a live system so we do not display too much information to the user so comment out the lines below
		//echo '<p class="error">' . $q . '</p>';
		//echo '<p class="error">' . mysqli_error($this->dbc) .'</p>';
	}

}
?>
