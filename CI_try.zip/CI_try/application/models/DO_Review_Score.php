<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * This class was coded by sayed mohammed alnajjar 201301587
 * with help from the Data Object Emitter program
*/


class DO_Review_Score extends mysqli_con {

	public $Score_ID=null;
	public $Score;
	public $User_ID;
	public $Score_Date;
	public $Review_ID;
	public $errorMsg;
	public $dbc=null;

	public function  __construct() /*DO_Reviews_Score() depricated name*/ {
                
		$this->getDBConnection();
}

	private function getDBConnection() {
		//replace with your own connection class
		//include_once "mysqli_connect.php";
		try{
			if($this->dbc == null){
				$db = new mysqli_con();
				$this->dbc = $db->getConnection();
			}
		return $this->dbc;
		}
		catch (Exception $e) {
			echo 'Caught exception: '.$e->getMessage();
			return null;
		}
	}


	public function get($Score_ID) {
		if($this->getDBConnection()){
			$q = "SELECT Score_ID, Score, User_ID, Score_Date, Review_ID FROM Review_Score where Score_ID=".$Score_ID;
			//create the prepared statement
			$stmt = $this->dbc->prepare($q);

			//bind the variables to the statement
			$stmt->bind_param('s', $Score_ID);

			//execute the statement
			if ($stmt->execute()) {

				/* store result */
				$stmt->store_result();

				//bind the output results to the members of the class
				$stmt->bind_result($this->Score_ID, $this->Score, $this->User_ID, $this->Score_Date, $this->Review_ID);

				//get the results of the query
				$stmt->fetch();

				$stmt->close();
                                return TRUE;
			}
			else {
//				echo '<p class="error">Execute failed</p>';
//				echo '<p class="error">' . mysqli_error($db) . '</p>';
                            return FALSE;
                        }
			}
			else{
//				echo '<p class="error">Could not connect to database</p>';
                        return false;}
	}


	public function save(){

		if ($this->getDBConnection()) {
			//guard against XSS
			$this->Score = strip_tags($this->Score);
			$this->User_ID = strip_tags($this->User_ID);
			$this->Review_ID = strip_tags($this->Review_ID);
			//help prevent SQL injection by escaping any special characters using mysqli_real_escape_string function
			$this->Score = mysqli_real_escape_string($this->dbc, $this->Score);
			$this->User_ID = mysqli_real_escape_string($this->dbc, $this->User_ID);
			$this->Review_ID = mysqli_real_escape_string($this->dbc, $this->Review_ID);

			if ($this->Score_ID == null) {
				$q = "INSERT INTO Review_Score( Score, User_ID, Score_Date, Review_ID) values( ?, ?, NOW(), ?)";
			} else {
				$q = "update Review_Score set Score=?, User_ID=?, Review_ID=?, where Score_ID=? ";
			}

			$stmt = $this->dbc->prepare($q);

			if ($stmt) {
				//code below is binding paramters to the statement
				if ($this->Score_ID == null){
					$stmt->bind_param('dss', $this->Score, $this->User_ID, $this->Review_ID); 				
                                                
                                } 
                                else 
                                    {
					$stmt->bind_param('dsss', $this->Score, $this->User_ID, $this->Score_ID);
				}

				//execute the statement and then check the result
				if (! $stmt->execute()) {
					//$this->displayError($q);
					return false;
				}
			} else {
				//$this->displayError($q);
				return false;
			}
			return true;
		} else {
			//echo '<p class="error">Could not connect to database</p>';
			return false;
		}
		return true;
	}


	public function delete(){
		if($this->getDBConnection()){
			$q = "DELETE FROM Review_Score WHERE Score_ID=" . mysql_escape_string($this->Score_ID);

			$r = mysqli_query($this->dbc, $q);

			if(!$r){
				//$this->displayError($q);
				return false;
			}

			return true;
		} else {
			//echo '<p class="error">Could not connect to database</p>';
			return false;
		}
	}


	public function isValid() {

		//declare array to hold any errors messages
		$errors = array();

		if (empty($this->Score))
			$errors[] = 'You must enter Score';
		if (empty($this->User_ID))
			$errors[] = 'You must enter User_ID';
		if (empty($this->Review_ID))
			$errors[] = 'You must enter Review_ID';

		return $errors;
	}

	private function displayError($q){
		echo '<p class="error">A database error occurred - contact the admin</p>';
		//when this is a live system so we do not display too much information to the user so comment out the lines below
		//echo '<p class="error">' . $q . '</p>';
		//echo '<p class="error">' . mysqli_error($this->dbc) .'</p>';
	}

}
?>
