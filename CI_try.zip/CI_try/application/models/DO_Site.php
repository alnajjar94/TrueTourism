<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * This class was coded by sayed mohammed alnajjar 201301587
 * with help from the Data Object Emitter program
*/

class DO_Site extends mysqli_con {

	public $Site_ID=null;
	public $Site_Name;
	public $Location_ID;
	public $Site_Description;
	public $Site_Picture;
	public $Category_ID;
	public $errorMsg;
	public $dbc=null;

	public function  __construct() /*DO_Site() depricated name*/ {

		$this->getDBConnection();
}

	private function getDBConnection() {
		//replace with your own connection class
		include_once "mysqli_con.php";
		try{
			if($this->dbc == null){
				$db = new mysqli_con();
				$this->dbc = $db->getConnection();
			}
		return $this->dbc;
		}
		catch (Exception $e) {
			echo 'Caught exception: '.$e->getMessage();
			return null;
		}
	}


	public function get($Site_ID) {
		if($this->getDBConnection()){
			$q = "SELECT Site_ID, Site_Name, Location_ID, Site_Description, Site_Picture, Category_ID FROM Site where Site_ID=".$Site_ID;
			//create the prepared statement
			$stmt = $this->dbc->prepare($q);

			//bind the variables to the statement


			//execute the statement
			if ($stmt->execute()) {

				/* store result */
				$stmt->store_result();

				//bind the output results to the members of the class
				$stmt->bind_result($this->Site_ID, $this->Site_Name, $this->Location_ID, $this->Site_Description, $this->Site_Picture, $this->Category_ID);

				//get the results of the query
				$stmt->fetch();

				$stmt->close();
			}
			else {
				echo '<p class="error">Execute failed</p>';
				//echo '<p class="error">' . mysqli_error($db) . '</p>';
			}
                }
			else{
				echo '<p class="error">Could not connect to database</p>';
                                }
			return false;
                                
	}
        
        public function getAll() {
		if($this->getDBConnection()){
                        $toReturn = Array();
                        /*$q = "SELECT Review_ID, Review, Review_Level, Review_Date, Review_Reply, Facility_ID, Review_Status,User_ID FROM Reviews where Facility_ID='".$Facility_ID."'";
echo $q."\n";*/
                        $sql = "SELECT * FROM Site;";
			//create the prepared statement
			$result = $this->dbc->query($sql);
                        /*$r = mysqli_query($this->dbc, $q);
                        if($r)
                        {
                        while ($row = mysqli_fetch_array($r)) {
                            $review = new DO_Reviews();
                            $review->get($row["Review_ID"]);
                            $toReturn[] = $row;
                        }*/
			if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                        $site = new DO_Site();
                                        $site->get($row["Site_ID"]);
                                        $toReturn[] = $site;
                                        
                                    }
                                    return $toReturn;
                                } else {
                                    echo '<script>alert("Error, No Sites were found!");</script>';
                                    return FALSE;
                                }
                             
                        
                
                                
			}
                
			else
				echo '<p class="error">Could not connect to database</p>';
			return false;
	}
        
        public function getByCategory($category_ID)
        {
            
		if($this->getDBConnection()){
                        $toReturn = Array();
                        /*$q = "SELECT Review_ID, Review, Review_Level, Review_Date, Review_Reply, Facility_ID, Review_Status,User_ID FROM Reviews where Facility_ID='".$Facility_ID."'";
echo $q."\n";*/
                        $sql = "SELECT * FROM Site WHERE Category_ID = $category_ID;";
			//create the prepared statement
			$result = $this->dbc->query($sql);
                        /*$r = mysqli_query($this->dbc, $q);
                        if($r)
                        {
                        while ($row = mysqli_fetch_array($r)) {
                            $review = new DO_Reviews();
                            $review->get($row["Review_ID"]);
                            $toReturn[] = $row;
                        }*/
			if ($result->num_rows > 0) {
                                    // output data of each row
                                    while($row = $result->fetch_assoc()) {
                                        $site = new DO_Site();
                                        $site->get($row["Site_ID"]);
                                        $toReturn[] = $site;
                                        
                                    }
                                    return $toReturn;
                                } else {
                                    echo '<script>alert("Error, No Sites were found!");</script>';
                                    return FALSE;
                                }
                             
                        
                
                                
			}
                
			else
				echo '<p class="error">Could not connect to database</p>';
			return false;
        }
        
        
	public function save(){

		if ($this->getDBConnection()) {
			//guard against XSS
			$this->Site_Name = strip_tags($this->Site_Name);
			$this->Location_ID = strip_tags($this->Location_ID);
			$this->Site_Description = strip_tags($this->Site_Description);
			$this->Site_Picture = strip_tags($this->Site_Picture);
			$this->Category_ID = strip_tags($this->Category_ID);
			//help prevent SQL injection by escaping any special characters using mysqli_real_escape_string function
			$this->Site_Name = mysqli_real_escape_string($this->dbc, $this->Site_Name);
			$this->Location_ID = mysqli_real_escape_string($this->dbc, $this->Location_ID);
			$this->Site_Description = mysqli_real_escape_string($this->dbc, $this->Site_Description);
			$this->Site_Picture = mysqli_real_escape_string($this->dbc, $this->Site_Picture);
			$this->Category_ID = mysqli_real_escape_string($this->dbc, $this->Category_ID);

			if ($this->Site_ID == null) {
				$q = "INSERT INTO Site( Site_Name, Location_ID, Site_Description, Site_Picture, Category_ID) values(?, ?, ?, ?, ?)";
			} else {
				$q = "update Site set Site_Name=?, Location_ID=?, Site_Description=?, Site_Picture=?, Category_ID=?, where Site_ID=? ";
			}

			$stmt = $this->dbc->prepare($q);

			if ($stmt) {
				//code below is binding paramters to the statement
				if ($this->Site_ID == null){
                                    $null = NULL;
					$stmt->bind_param('sssbs', $this->Site_Name, $this->Location_ID, $this->Site_Description, $null, $this->Category_ID);
                                        
                                        $stmt->send_long_data(3, file_get_contents($this->Site_Picture));
                                        } 
                                        else 
                                            {
					$stmt->bind_param('sssbss', $this->Site_Name, $this->Location_ID, $this->Site_Description, $this->Site_Picture, $this->Site_ID);
				}

				//execute the statement and then check the result
				if (! $stmt->execute()) {
					$this->displayError($q);
					return false;
				}
			} else {
				$this->displayError($q);
				return false;
			}
			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
		return true;
	}


	public function delete(){
		if($this->getDBConnection()){
			$q = "DELETE FROM Site WHERE Site_ID=" . mysql_escape_string($this->Site_ID);

			$r = mysqli_query($this->dbc, $q);

			if(!$r){
				$this->displayError($q);
				return false;
			}

			return true;
		} else {
			echo '<p class="error">Could not connect to database</p>';
			return false;
		}
	}


	public function isValid() {

		//declare array to hold any errors messages
		$errors = array();

		if (empty($this->Site_Name))
			$errors[] = 'You must enter Site_Name';
		if (empty($this->Location_ID))
			$errors[] = 'You must enter Location_ID';
		if (empty($this->Site_Description))
			$errors[] = 'You must enter Site_Description';
		if (empty($this->Site_Picture))
			$errors[] = 'You must enter Site_Picture';
		if (empty($this->Category_ID))
			$errors[] = 'You must enter Category_ID';

		return $errors;
	}

	private function displayError($q){
		echo '<p class="error">A database error occurred - contact the admin</p>';
		//when this is a live system so we do not display too much information to the user so comment out the lines below
		//echo '<p class="error">' . $q . '</p>';
		//echo '<p class="error">' . mysqli_error($this->dbc) .'</p>';
	}

}
?>
