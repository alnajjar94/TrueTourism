<?php

/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Pages extends CI_Controller {

        public function view($page = 'Home')
        {
            
            //check if the get has any data or else proceed with default
            if(isset($_GET["Page"]))
            {
                //trim all special characters for security
                $page = preg_replace("/[^ \w]+/", "", $_GET["Page"]);
            }
            
            if ( ! file_exists(APPPATH.'views/'.$page.'.php'))
            {
                    // Whoops, we don't have a page for that!
                    show_404();
            }
            
            
            
            $data['title'] = ucfirst($page); // Capitalize the first letter
            if($page == "AjaxHandler")
            {
                $this->load->view($page, $data);
            }
            elseif($page == "AjaxReviews")
            {
                $this->load->view($page, $data);
            }
            else{
                $this->load->view('header', $data);
                $this->load->view($page, $data);
                $this->load->view('footer', $data);
            }
        }
}
?>