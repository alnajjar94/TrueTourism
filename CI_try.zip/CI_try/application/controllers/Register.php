<?php
defined('BASEPATH') OR exit('No direct script access allowed');


/*
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Register
 *
 * @author 20130
 */
class Register extends CI_Controller {
    //put your code here
    public function index()
	{
            $this->load->view('header');
            $this->load->view('Register_View');
            $this->load->view('footer');
            
	}
}
