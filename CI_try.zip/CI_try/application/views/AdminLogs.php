<?php defined('BASEPATH') OR exit('No direct script access allowed');
include_once 'application/models/mysqli_con.php';
include_once 'application/models/DO_Site.php';
include_once 'application/models/DO_Location.php';
include_once 'application/models/DO_Site_Category.php';
include_once 'application/models/DO_Logs.php';
if(isset($_SESSION["username"]))
{
    $man = new DO_users();
    $man->getUser($_SESSION["username"]);
    if($man->User_Role != "Admin"){ die();}
}
/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$tmp = new DO_Logs();
$Logs = $tmp->getAll();
?>
<script src="js/jquery-1.js"></script>
<style>
#myInput {
    background-image: url('/css/searchicon.png'); /* Add a search icon to input */
    background-position: 10px 12px; /* Position the search icon */
    background-repeat: no-repeat; /* Do not repeat the icon image */
    width: 100%; /* Full-width */
    font-size: 16px; /* Increase font-size */
    padding: 12px 20px 12px 40px; /* Add some padding */
    border: 1px solid #ddd; /* Add a grey border */
    margin-bottom: 12px; /* Add some space below the input */
}

#myTable {
    border-collapse: collapse; /* Collapse borders */
    width: 100%; /* Full-width */
    border: 1px solid #ddd; /* Add a grey border */
    font-size: 18px; /* Increase font-size */
}

#myTable th, #myTable td {
    text-align: left; /* Left-align text */
    padding: 12px; /* Add padding */
}

#myTable tr {
    /* Add a bottom border to all table rows */
    border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
    /* Add a grey background color to the table header and on hover */
    background-color: #f1f1f1;
}
</style>
<br />
<div class=" row">
    <input class="form-control col-12" type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for Logs..">
</div>
<div class="row">
    <table id="myTable" class="col-12">
  <tr class="header">
    <th style="width:25%;">Logged Action</th>
    <th style="width:25%;">User ID</th>
    <th style="width:25%;">Date Created</th>
    <th style="width:25%;">Logged Message</th>
  </tr>
  
      <?php
        if($Logs)
        {
            foreach ($Logs as $Log) {
                echo "<tr><td>$Log->Logged_Action</td><td>$Log->User_ID</td><td>$Log->Log_Date</td><td>$Log->Log_Message</td></tr>";
            }
        }
        else {
            echo "<tr><td colspan=\"4\"><center>No Logs Are Available</center></td></tr>";
        }

      
    
      ?>
  
</table>
</div> 
 <script src="js/FilteredTable.js" type="text/javascript"></script>