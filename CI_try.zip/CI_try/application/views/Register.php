<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?> <script src="js/RegisterScripts.js" type="text/javascript"></script> <?php
include_once 'application/models/mysqli_con.php';
include_once 'application/models/DO_users.php';
////////////////////////////////////////////////////////
///////////////////processing////////////////////////////////
///////////////////////////////////////////////////////
if($this->input->post('Submitted') !== NULL){
    //echo 'SUBMITION IS SET'; if submitted do the following
    
    if($this->input->post('password') === $this->input->post('confirm'))
    {
        $user = new DO_users();
        if(!$user->getUser($_POST["username"]))
        {
            $user = new DO_users();
            $db = new mysqli_con();
            $dbc = $db->getConnection();
            $verification_num = "123456789";
            $exists = TRUE;
            while($exists)
            {
                $q = "SELECT sha2(rand(), 224) FROM DUAL;";
                $r = mysqli_query($dbc, $q);
                if($r)
                {
                    $row = mysqli_fetch_array($r);
                    $verification_num = $row[0];
                    $q = "SELECT * FROM users WHERE `User_Verification_Num`='$verification_num';";
                    $r = mysqli_query($dbc, $q);
                    if(mysqli_num_rows($r) == 0)
                    {
                        $exists = FALSE;
                    }
                    else
                    {
                        $exists = TRUE;
                    }
                }
                else
                {
                    die("database Error please try to register again or contact the admin");
                }
            }
            //$db->closeDB();
            $user->User_Name = $_POST['name'];
            $user->User_Email = $this->input->post('email');
            $user->User_NickName = $this->input->post('username');
            $user->User_Password = $this->input->post('password');
            $user->User_Verified = "Registered";
            $user->User_Verification_Num = $verification_num;
            /*$q = "INSERT INTO users(User_Name,User_Email,User_NickName,User_Password,"
                    . "User_Verified,User_Verification_Num) VALUES($user->User_Name' ,"
                    . " '$user->User_Email', '$user->User_NickName', '$user->User_Password',"
                    . " '$user->User_Verified', '$user->User_Verification_Num');";
            $r = mysqli_query($dbc, $q);
            
            if($r)
            {
                
            }
            else
            {
                
                $Error[] = mysqli_error($dbc);
            }*/
            if($user->save()){
                $Success[] = "Registered Successfully please verify your email to login";
            }
 else {                $Error[] = 'error registering your data';}
            SendPHPMail($user->User_Email, "<html><head></head><body>
                  <h1>Dear $user->User_Name,</h1>   
                    <p>True Tourism Website thanks you for registering if it is not you please ignore the message if its you</p>
                    <p>you may verify your E-mail using this link: <br />
                    <a href=\"http://ec2-54-171-69-5.eu-west-1.compute.amazonaws.com/CI_try/index.php?Page=Login&UID=$user->User_NickName&VN=$user->User_Verification_Num\">"
                    . "http://ec2-54-171-69-5.eu-west-1.compute.amazonaws.com/CI_try/index.php?Page=Login&UID=$user->User_NickName&VN=$user->User_Verification_Num
                        </a></p>
    </body></html>", "Verify Registeration");
            
        }
        else 
        {
            $Error[] = 'username already exists';
        }
    }
    else 
    {
        $Error[] = 'passwords MISMATCH!!';
    }
}
 else {
    //echo 'SUBMITION IS NOT SET'; if not submitted do the following
}

?>

<style>
    #playground-container {
    height: 500px;
    overflow: hidden !important;
    -webkit-overflow-scrolling: touch;
}
body, html{
        height: 100%;
 	
}
.MainBG{
    position: absolute;
width: 100%;
    background-repeat: no-repeat;
 	background:url(https://i.ytimg.com/vi/4kfXjatgeEU/maxresdefault.jpg);
 	font-family: 'Oxygen', sans-serif;
        background-size: cover;
        
}
.main{
 	margin:50px 15px;
}

h1.title { 
	font-size: 50px;
	font-family: 'Passion One', cursive; 
	font-weight: 400; 
}

hr{
	width: 10%;
	color: #fff;
}

.form-group{
	margin-bottom: 15px;
}

label{
	margin-bottom: 15px;
}

input,
input::-webkit-input-placeholder {
    font-size: 11px;
    padding-top: 3px;
}

.main-login{
 	background-color: #fff;
    /* shadows and rounded borders */
    -moz-border-radius: 2px;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);

}
.form-control {
    height: auto!important;
padding: 8px 12px !important;
}
.input-group {
    -webkit-box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
    -moz-box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
    box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
}
#button {
    border: 1px solid #ccc;
    margin-top: 28px;
    padding: 6px 12px;
    color: #666;
    text-shadow: 0 1px #fff;
    cursor: pointer;
    -moz-border-radius: 3px 3px;
    -webkit-border-radius: 3px 3px;
    border-radius: 3px 3px;
    -moz-box-shadow: 0 1px #fff inset, 0 1px #ddd;
    -webkit-box-shadow: 0 1px #fff inset, 0 1px #ddd;
    box-shadow: 0 1px #fff inset, 0 1px #ddd;
    background: #f5f5f5;
    background: -moz-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #f5f5f5), color-stop(100%, #eeeeee));
    background: -webkit-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -o-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -ms-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f5f5f5', endColorstr='#eeeeee', GradientType=0);
}
.main-center{
 	margin-top: 30px;
 	margin: 0 auto;
 	max-width: 400px;
    padding: 10px 40px;
	background:#009edf;
	    color: #FFF;
    text-shadow: none;
	-webkit-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
-moz-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);

}
span.input-group-addon i {
    color: #009edf;
    font-size: 17px;
}

.login-button{
	margin-top: 5px;
}

.login-register{
	font-size: 11px;
	text-align: center;
}
footer{
    
    display: hidden;
}
.input-group-addon{
    width: 60px;
}
</style>

<div class="container">
			<div class="row main">
				<div class="main-login main-center">
				<h5>Sign up to True Tourism to add a review.</h5>
                                <form class="" method="POST" action="index.php?Page=Register">
						
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Your Name</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon">
                                                                            <img src="glyphicons/glyphicons-35-old-man.png" alt="name"/>
                                                                        
                                                                        </span>
                                                                    <input type="text" required class="form-control" name="name" id="name"  placeholder="Enter your Name"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="email" class="cols-sm-2 control-label">Your Email</label>
							<div class="cols-sm-10">
								<div class="input-group">
                                                                    <span class="input-group-addon">
                                                                        <img src="glyphicons/glyphicons-11-envelope.png" alt="email"/>
                                                                    </span>
									<input type="text" required class="form-control" name="email" id="email"  placeholder="Enter your Email"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="username" class="cols-sm-2 control-label">username</label>
							<div class="cols-sm-10">
								<div class="input-group">
                                                                    <span class="input-group-addon">
                                                                        <img src="glyphicons/glyphicons-44-group.png" alt="username"/>
                                                                    </span>
									<input type="text" required class="form-control" name="username" id="username"  placeholder="Enter your Username"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon">
                                                                            <img src="glyphicons/glyphicons-204-lock.png" alt="pass"/>
                                                                        </span>
									<input type="password" required class="form-control" name="password" id="password"  placeholder="Enter your Password"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="confirm" class="cols-sm-2 control-label">Confirm Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon"><img src="glyphicons/glyphicons-204-lock.png" alt="pass"/></span>
									<input type="password" required class="form-control" name="confirm" id="confirm"  placeholder="Confirm your Password"/>
								</div>
							</div>
						</div>

						<div class="form-group ">
                                                    <input type="submit" id="button" name="Submitted" value="Register" class="btn btn-primary btn-lg btn-block login-button">
						</div>
						
                                                
					</form>
                                <div id="Results"></div>
                                <?php  /**
                                 * display error and success
                                 */
                                
                                if(isset($Error[0])){

        
    
?>

<div class="alert alert-danger">
    <strong>There were Errors!</strong><br /><ul> <?php 
    
        foreach ($Error as $value) {
            echo "<li>$value</li>";
        }
    
    ?></ul>
</div>
<?php
    }
elseif(isset($Success[0])){
    


?>
<div class="alert alert-success">
  <strong>Success!</strong><br /> <ul><?php  
  
  foreach ($Success as $value) {
      echo "<li> $value </li>";
  }
  
  
  ?> </ul>
</div>
<?php

}?> <?php

                                
                                
                                /**
                                 * end of messages display
                                 */
                                ?>
				</div>
			</div>
		

		 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
