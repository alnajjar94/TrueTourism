<?php defined('BASEPATH') OR exit('No direct script access allowed');
include_once 'application/models/mysqli_con.php'; 
include_once 'application/models/DO_Reviews.php';
include_once 'application/models/DO_users.php';
include_once 'application/models/DO_Site.php';
include_once 'application/models/DO_Site_Facility.php';
include_once 'application/models/DO_Site_Category.php';
include_once 'application/models/DO_User_Sites.php';
include_once 'application/models/DO_Logs.php';
$sameuser = FALSE;
/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if (isset($_SESSION["username"]))
{
    $user_ID = $_SESSION["username"];
    $user = new DO_users();
    if(!$user->getUser($user_ID))
    {
        die('<div class="alert alert-danger">
    <strong>There were Errors!</strong><br />YOUR PROFILE COULD NOT BE FOUND FOR SOME REASON PLEASE CONTACT THE ADMIN');
    }
    
}
else
{
    die('<div class="alert alert-danger">
    <strong>There were Errors!</strong><br />PLEASE LOGIN TO VIEW YOUR PROFILE');
}
if(isset($_POST["FavSite"]))
{
    $Fav = new DO_User_Sites();
    if($_POST["FavSite"] == "Add")
    {
        $Fav->Category_ID = $_POST["FavCategory"];
        $Fav->User_ID = $user->User_ID;
        if($Fav->save())
        {
            $Success[] = "Add Successful";
        }
        else 
        {
            $Error[] = "Adding your favorite category has failed";
        }
    }
    else
    {
        if($Fav->get($_POST["CurFav"]))
        {
            if($Fav->delete())
            {
                $Success[] = "Delete Successful";
            }
            else
            {
                $Error[] = "Deletion Failed";
            }
        }
        else
        {
            $Error[] = "Error Retrieving information about the favorite category to delete";
        }
    }
}
if(isset($_POST["details"]))
{
    if(isset($_SESSION["username"]))
    {
        $newuser = new DO_users();
        $newuser->getUser($_SESSION["username"]);
        $newuser->User_Email = $_POST["email"];
        $newuser->User_Name = $_POST["name"];
        $newuser->User_Verified = "pending";
        $newuser->User_Verification_Num = "22";
        
        
        if($_FILES["userPicture"]["name"])
        {
            //print_r($_FILES);
            $q = "UPDATE users SET `User_Name`=?, `User_Email`=?, `User_Picture`=? WHERE `User_ID`=$newuser->User_ID";
            $db = new mysqli_con();
            $dbc = $db->getConnection();
            $stmt = $dbc->prepare($q);
            $null = NULL;
            $stmt->bind_param('ssb',$newuser->User_Name , $newuser->User_Email, $null);
            $stmt->send_long_data(2, file_get_contents($_FILES["userPicture"]["tmp_name"]));
            if($stmt)
            {
                $currUser = new DO_users();
                $currUser->getUser($_SESSION["username"]);
                $Log = new DO_Logs();
                $Log->Logged_Action = "Change of user info by $currUser->User_NickName";
                $Log->Log_Message = "previous email was: $currUser->User_Email - the new email is now:$newuser->User_Email";
                $Log->save();
                $stmt->execute();
                $Success[] = "successfully applied new information";
            }
            else
            {
                $Error[] = "Database error";
            }
        }
        else
        {
            $q = "UPDATE users SET `User_Name`=?, `User_Email`=? WHERE `User_ID`=?";
            $db = new mysqli_con();
            $dbc = $db->getConnection();
            $stmt = $dbc->prepare($q);
            $stmt->bind_param('ssi',$newuser->User_Name , $newuser->User_Email, $newuser->User_ID);
            if($stmt)
            {
                $stmt->execute();
                $Success[] = "successfully applied new information";
            }
            else
            {
                $Error[] = "Database error";
            }
        }
        
    } 
    else
    {
        $Error[] = "Please login to edit your profile";
    }
}
elseif(isset($_POST["passwordChange"]))
{
    
    $newuser = new DO_users();
    $newuser->getUser($_SESSION["username"]);
    
}
/*if(isset($_GET["ID"]))
{
    $user_ID = $_GET["ID"];
    $user = new DO_users();
    if(!$user->get($user_ID))
    {
        die('<div class="alert alert-danger">
    <strong>There were Errors!</strong><br />NO USER WERE FOUND PLEASE CHOOSE A DIFFERENT USER OR REPORT TO ADMIN');
    }
}*/

if(isset($_SESSION["username"]))
{ 
    if($_SESSION["username"] == $user->User_NickName)
    {
        $sameuser = TRUE;
    }
    else
    {
        $sameuser = FALSE;
    }
}
 else {
    $sameuser = FALSE;
}
///////////////////////
$user->getUser($user_ID);
///////////////////////
$tmp = new DO_Site_Category();
$categories = $tmp->getAll();
$tmp = new DO_User_Sites();
$favCategories = $tmp->getByUser($user->User_ID);
////////////////////////
?>
<style>
    #playground-container {
    height: 500px;
    overflow: hidden !important;
    -webkit-overflow-scrolling: touch;
}
body, html{
        height: 100%;
 	
}
.MainBG{
    position: absolute;
width: 100%;
    background-repeat: no-repeat;
 	background:url(https://i.ytimg.com/vi/4kfXjatgeEU/maxresdefault.jpg);
 	font-family: 'Oxygen', sans-serif;
        background-size: cover;
        
}
.main{
 	margin:50px 15px;
}

h1.title { 
	font-size: 50px;
	font-family: 'Passion One', cursive; 
	font-weight: 400; 
}

hr{
	width: 10%;
	color: #fff;
}

.form-group{
	margin-bottom: 15px;
}

label{
	margin-bottom: 15px;
}

input,
input::-webkit-input-placeholder {
    font-size: 11px;
    padding-top: 3px;
}

.main-login{
 	background-color: #fff;
    /* shadows and rounded borders */
    -moz-border-radius: 2px;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);

}
.form-control {
    height: auto!important;
padding: 8px 12px !important;
}
.input-group {
    -webkit-box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
    -moz-box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
    box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
}
#button {
    border: 1px solid #ccc;
    margin-top: 28px;
    padding: 6px 12px;
    color: #666;
    text-shadow: 0 1px #fff;
    cursor: pointer;
    -moz-border-radius: 3px 3px;
    -webkit-border-radius: 3px 3px;
    border-radius: 3px 3px;
    -moz-box-shadow: 0 1px #fff inset, 0 1px #ddd;
    -webkit-box-shadow: 0 1px #fff inset, 0 1px #ddd;
    box-shadow: 0 1px #fff inset, 0 1px #ddd;
    background: #f5f5f5;
    background: -moz-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #f5f5f5), color-stop(100%, #eeeeee));
    background: -webkit-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -o-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -ms-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f5f5f5', endColorstr='#eeeeee', GradientType=0);
}
.main-center{
 	margin-top: 30px;
 	margin: 0 auto;
 	max-width: 400px;
    padding: 10px 40px;
	background:#009edf;
	    color: #FFF;
    text-shadow: none;
	-webkit-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
-moz-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);

}
span.input-group-addon i {
    color: #009edf;
    font-size: 17px;
}

.login-button{
	margin-top: 5px;
}

.login-register{
	font-size: 11px;
	text-align: center;
}
footer{
    
    display: hidden;
}
.input-group-addon{
    width: 60px;
}
</style>
<?php if($sameuser){ ?>
<div class="container">
			<div class="row main">
				<div class="main-login main-center">
				<h5>User Profile</h5>
                                <form class="" method="POST" action="index.php?Page=UserInfo" enctype="multipart/form-data">
						
						

						<div class="form-group">
							<label class="cols-sm-2 control-label">User Picture</label>
							<div class="cols-sm-10">
                                                            <img class="form-control" src="data:image/jpeg;base64,<?php echo  base64_encode( $user->User_Picture ) ?>">
							</div>
						</div>
                                                
                                                <div class="form-group">
							<label for="userPicture" class="cols-sm-2 control-label">upload your new picture</label>
							
                                                        <div class="cols-sm-10">
                                                            <div class="input-group">
                                                                <span class="input-group-addon">
                                                                    <img src="glyphicons/glyphicons-204-lock.png" alt="name"/>
                                                                </span>
                                                            <input type="file" id="userPicture" name="userPicture" class="form-control" >
                                                            </div>
                                                        </div>
                                                </div> 
						<div class="form-group">
							<label for="name" class="cols-sm-2 control-label">Name</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon">
                                                                            <img src="glyphicons/glyphicons-204-lock.png" alt="name"/>
                                                                        </span>
                                                                    <input required value="<?php echo $user->User_Name; ?>" type="text" class="form-control" name="name" id="name"  placeholder="Enter your name"/>
								</div>
							</div>
						</div>
                                                
                                                <div class="form-group">
							<label for="email" class="cols-sm-2 control-label">email</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon">
                                                                            <img src="glyphicons/glyphicons-204-lock.png" alt="email"/>
                                                                        </span>
                                                                    <input required value="<?php echo $user->User_Email; ?>" type="email" class="form-control" name="email" id="email"  placeholder="Enter your email"/>
								</div>
							</div>
						</div>
						

						<div class="form-group ">
                                                    <input type="submit" id="detailsbutton" name="details" value="Apply Changes" class="btn btn-primary btn-lg btn-block login-button">
                                    </div>
						
                                                
					</form>
                  
                                        <hr>
                                        
                                        <form method="POST" action="index.php?Page=UserInfo" >
                                        <div class="form-group">
							<label for="pass" class="cols-sm-2 control-label">Current Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon">
                                                                            <img src="glyphicons/glyphicons-204-lock.png" alt="pass"/>
                                                                        </span>
                                                                    <input required type="password" class="form-control" name="pass" id="pass"  placeholder="Enter your password"/>
								</div>
							</div>
						</div>
                                                
                                                <div class="form-group">
							<label for="newpass" class="cols-sm-2 control-label">New Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon">
                                                                            <img src="glyphicons/glyphicons-204-lock.png" alt="newpass"/>
                                                                        </span>
                                                                    <input required type="password" class="form-control" name="newpass" id="newpass"  placeholder="Enter your new password"/>
								</div>
							</div>
						</div>

                                                <div class="form-group">
							<label for="confirm" class="cols-sm-2 control-label">Confirm New Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon">
                                                                            <img src="glyphicons/glyphicons-204-lock.png" alt="confirm"/>
                                                                        </span>
                                                                    <input required type="password" class="form-control" name="confirm" id="confirm"  placeholder="confirm your new password"/>
								</div>
							</div>
						</div>
                                            <div class="form-group">
                                                <input type="submit" id="passbutton" name="passwordChange" value="Change Password" class="btn btn-primary btn-lg btn-block login-button">
                                            </div>
                                        </form>
                                        <form method="POST" action="index.php?Page=UserInfo" >
                                            
                                            <div class="form-group">
							<label for="FavCategory" class="cols-sm-2 control-label">Available Categories</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon">
                                                                            <img src="glyphicons/glyphicons-204-lock.png" alt="FavCategories" />
                                                                        </span>
                                                                    <select required class="form-control" name="FavCategory" id="FavCategory" >
                                                                        <?php
                                                                        
                                                                            foreach ($categories as $category) {
                                                                                echo '<option value="'.$category->Category_ID.'" > '.$category->Category_Name.' </option>';
                                                                            }
                                                                        
                                                                        ?>
                                                                    </select>
								</div>
							</div>
						</div>
                                                <div class="form-group">
                                                <input type="submit" id="FavAdd" name="FavSite" value="Add" class="btn btn-primary btn-lg btn-block login-button">
                                            </div>
                                            </form><form method="POST" action="index.php?Page=UserInfo" >
                                                <div class="form-group">
							<label for="CurFav" class="cols-sm-2 control-label">Current Favorites</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon">
                                                                            <img src="glyphicons/glyphicons-204-lock.png" alt="CurFav"/>
                                                                        </span>
                                                                    <select required class="form-control" name="CurFav" id="CurFav"  >
                                                                        <?php
                                                                        
                                                                            foreach ($favCategories as $User_Site) {
                                                                                $category = new DO_Site_Category();
                                                                                $category->get($User_Site->Category_ID);
                                                                                echo '<option value="'.$User_Site->Entry_ID.'" > '.$category->Category_Name.' </option>';
                                                                            }
                                                                        
                                                                        ?>
                                                                    </select>
								</div>
							</div>
						</div>
                                                
                                            
                                            
                                            <div class="form-group">
                                                <input type="submit" id="FavRemove" name="FavSite" value="Remove" class="btn btn-primary btn-lg btn-block login-button">
                                            </div>
                                            
                                            
                                            
                                            
                                            
                                            
                                        </form>

                                                
                                <?php 
                                /**
                                 * display error and success
                                 */
                                
                                if(isset($Error[0])){

        
    
?>
<div class="alert alert-danger">
    <strong>There were Errors!</strong><br /><ul> <?php 
    
        foreach ($Error as $value) {
            echo "<li>$value</li>";
        }
    
    ?></ul>
</div>
<?php
    }
elseif(isset($Success[0])){
    


?>
<div class="alert alert-success">
  <strong>Success!</strong><br /> <ul><?php  
  
  foreach ($Success as $value) {
      echo "<li> $value </li>";
  }
  
  
  ?> </ul>
</div>
<?php

}?><?php

                                
                                
                                /**
                                 * end of messages display
                                 */
                                
                                
                                
                                
                                
?></div>
                            <?php
                            /******************************************************************************************************************8
                             * if the user is different this page will be shown instead
                             * 
                             * 
                             */
}
                            else {
                                die("you may view only your own ProfilePage");
                            }
                           
                            