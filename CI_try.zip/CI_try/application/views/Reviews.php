<?php defined('BASEPATH') OR exit('No direct script access allowed');
include_once 'application/models/mysqli_con.php'; 
include_once 'application/models/DO_Reviews.php';
include_once 'application/models/DO_users.php';
include_once 'application/models/DO_Site.php';
include_once 'application/models/DO_Site_Facility.php';
include_once 'application/models/DO_Logs.php';
include_once 'application/models/DO_Location.php';
?><script src="js/jquery-1.js"></script><?php
/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//print_r($_SESSION);
//print_r($_POST);
if(isset($_SESSION["username"])){$currUser = new DO_users();$currUser->getUser($_SESSION["username"]);}

?>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=ki8gx5frvdjovzusqj6657yi1kfd5i52xghdkcw4twevigx2"></script> <script>tinymce.init({ selector:'textarea' });</script> <?php
/**
 * get id of facility to review it
 */
$ID = 1;
if(isset($_POST["ID"]))
{
    $ID = $_POST["ID"];
    
}
if(isset($_GET["ID"]))
{
    $ID = $_GET["ID"];
}
if(isset($_GET["id"]))
{
    $ID = $_GET["id"];
}
if(isset($_POST["id"]))
{
    $ID = $_POST["id"];
}
/**
 * if edit and reply is submitted handle it here
 */
if(isset($_POST["ModalSubmit"]))
{
    if($_POST["ModalSubmit"] == "Edit")
    {
        $editedReview = new DO_Reviews();
        $editedReview->get($_POST["RID"]);
        $editedReview->Review = $_POST["ModalTextArea"];
        $editedReview->Facility_ID = $ID;
        $editedReview->Review_Status = "Active";
        if($editedReview->save())
        {
            $Success[] = "your edited Review has been submitted";
        }
        else
        {
            $Error[] = "your edited Review experienced unexpected results";
        }
    }
    elseif ($_POST["ModalSubmit"] == "Reply")
    {
        $newReview = new DO_Reviews();
        $newReview->get($_POST["RID"]);
        $savedReview = new DO_Reviews();
        $savedReview->Review_Reply = $newReview->Review_ID;
        $savedReview->Review_Level = ($newReview->Review_Level + 1);
        $savedReview->Facility_ID = $ID;
        $savedReview->Review_Status = "Active";
        $user = new DO_users();
        $user->getUser($_SESSION["username"]);
        $savedReview->User_ID = $user->User_ID;
        $savedReview->Review = $_POST["ModalTextArea"];
        if($savedReview->save())
        {
            $Success[] = "your Review has been submitted";
        }
        else
        {
            $Error[] = "your Review experienced unexpected results";
        }
    }
    elseif($_POST["ModalSubmit"] == "BanReview")
    {
        $editedReview = new DO_Reviews();
        $editedReview->get($_POST["RID"]);
        $editedReview->Review = "Banned";
        $Log = new DO_Logs();
        $Log->Logged_Action = "ban of the review ID : $_POST[RID]";
        $Log->Log_Message = $_POST["ModalTextArea"];
        $Log->User_ID = $_SESSION["username"];
        
        $editedReview->Facility_ID = $ID;

        if($editedReview->save())
        {
            $Success[] = "the Review has been Banned";
            if(!$Log->save())
            {
                $Error[] = "unable to add Log entry";
            }
        }
        else
        {
            $Error[] = "banning Review experienced unexpected results";
        }
    }
    else
    {
        $Error[] = "Not Implemented Modal Submission if this was supposed to do something"
                . "\n please inform the admin";
    }
}
/**
 * delete button is pressed and the comment id is in $_POST["Comment"]
 */
if(isset($_POST["DELETE"]))
{
    $comment_ID = $_POST["Comment"];
    $comment = new DO_Reviews();
    $comment->get($comment_ID);
    $comment->Review = "Deleted Review";
    
    //print_r($_POST);

    if($comment->save())
    {
        $Success[] = "Comment Deleted successfully";
    }
    else 
    {
        $Error[] = "Comment could not be deleted"; 
    }
}
if(isset($_POST["submitted"]))
{
    if(isset($_SESSION["username"]))
    {
        $Review = new DO_Reviews();
        $Review->Review = $_POST["Review"];
        $Review->Facility_ID = $_POST["ID"];
        $user = new DO_users();
        $user->getUser($_SESSION["username"]);
        $Review->User_ID = $user->User_ID;
        $Review->Review_Status = "Active";
        $Review->save();
    }
    else
    {
        $Error[] = "please login to write a review";
    }
}
$tmp = new DO_Reviews();
$Review_List = $tmp->getByFac($ID);
if($Review_List)
{
$Review_List = $tmp->AddReplies($ID,$Review_List);
}

///////////////////////////////////////////////////////////////////////////////////////////
/*
 * For Inserting into DB

$db = mysqli_connect("localhost","root","","DbName"); //keep your db name
$image = addslashes(file_get_contents($_FILES['images']['tmp_name']));
//you keep your column name setting for insertion. I keep image type Blob.
$query = "INSERT INTO products (id,image) VALUES('','$image')";  
$qry = mysqli_query($db, $query);

* For Accessing image From Blob

$db = mysqli_connect("localhost","root","","DbName"); //keep your db name
$sql = "SELECT * FROM products WHERE id = $id";
$sth = $db->query($sql);
$result=mysqli_fetch_array($sth);
echo '<img src="data:image/jpeg;base64,'.base64_encode( $result['image'] ).'"/>';
 * 
 * 
 */

                                /**
                                 * display error and success
                                 */
                                echo '<div id="Results">';
                                if(isset($Error[0])){

        
    
?>

<div class="alert alert-danger">
    <strong>There were Errors!</strong><br /><ul> <?php 
    
        foreach ($Error as $value) {
            echo "<li>$value</li>";
        }
    
    ?></ul>
</div>
<?php
    }
elseif(isset($Success[0])){
    


?>
<div class="alert alert-success">
  <strong>Success!</strong><br /> <ul><?php  
  
  foreach ($Success as $value) {
      echo "<li> $value </li>";
  }
  
  
  ?> </ul>
</div>
<?php

}?> </div> <?php

                                
                                
                                /**
                                 * end of messages display
                                 */
                                
                                
                                
                                
                                
                                
/**
 * display facility information
 * $Site is a facility
 * 
 */
$Site = new DO_Site_Facility();
$Sited = new DO_Site();
$Location = new DO_Location();
$Site->get($ID);
$Sited->get($Site->Site_ID);
$Location->getByName($Sited->Site_Name);

echo '<div class="row" style="background-color: #E4E4E4;Padding:1%;" ><div class="col-3"></div><div class="col-6"><center><a title="click to move to google earth location" href="https://www.google.com/maps/@'.$Location->Latitude.','.$Location->Longtitude.',17z"><img class="img-thumbnail" width="50%" src="data:image/jpeg;base64,'.base64_encode( $Site->Facility_Picture ).'"/></a>';
       if(isset($_SESSION['username'])){ echo '<br /><form class="rating">
  <label>
    <input type="radio" id="'.$ID.'"  name="FacRate" value="1" />
    <span class="icon">★</span>
  </label>
  <label>
    <input type="radio" id="'.$ID.'"  name="FacRate" value="2" />
    <span class="icon">★</span>
    <span class="icon">★</span>
  </label>
  <label>
    <input type="radio" id="'.$ID.'"  name="FacRate" value="3" />
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>   
  </label>
  <label>
    <input type="radio" id="'.$ID.'"  name="FacRate" value="4" />
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>
  </label>
  <label>
    <input type="radio" id="'.$ID.'" name="FacRate" value="5" />
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>
  </label>
       </form>';}
        echo '</center></div><div class="col-3"></div></div>';
echo '<div class="row" style="background-color: #E4E4E4;" ><div class="col-3"></div><div class="col-6"><center>'.$Site->Facility_Description.'</center></div><div class="col-3"></div></div>';
?>



<?php include 'application/views/scriptsForReviews.php';?>
<link href="css/ReviewsStyle.css" rel="stylesheet" type="text/css"/>
<style>
    #playground-container {
    height: 500px;
    overflow: hidden !important;
    -webkit-overflow-scrolling: touch;
}
body, html{
        height: 100%;
 	
}
.MainBG{
    position: absolute;
width: 100%;
    background-repeat: no-repeat;
 	/*background:url(https://i.ytimg.com/vi/4kfXjatgeEU/maxresdefault.jpg);*/
 	font-family: 'Oxygen', sans-serif;
        background-size: cover;
        
}
.MainBG{
    background-color: #E4E4E4;
}
.main{
 	margin:50px 15px;
}

h1.title { 
	font-size: 50px;
	font-family: 'Passion One', cursive; 
	font-weight: 400; 
}

hr{
	width: 10%;
	color: #fff;
}

.form-group{
	margin-bottom: 15px;
}

label{
	margin-bottom: 15px;
}

input,
input::-webkit-input-placeholder {
    font-size: 11px;
    padding-top: 3px;
}

.main-login{
 	background-color: #fff;
    /* shadows and rounded borders */
    -moz-border-radius: 2px;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);

}
.form-control {
    height: auto!important;
padding: 8px 12px !important;
}
.input-group {
    -webkit-box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
    -moz-box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
    box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
}
#button {
    border: 1px solid #ccc;
    margin-top: 28px;
    padding: 6px 12px;
    color: #666;
    text-shadow: 0 1px #fff;
    cursor: pointer;
    -moz-border-radius: 3px 3px;
    -webkit-border-radius: 3px 3px;
    border-radius: 3px 3px;
    -moz-box-shadow: 0 1px #fff inset, 0 1px #ddd;
    -webkit-box-shadow: 0 1px #fff inset, 0 1px #ddd;
    box-shadow: 0 1px #fff inset, 0 1px #ddd;
    background: #f5f5f5;
    background: -moz-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #f5f5f5), color-stop(100%, #eeeeee));
    background: -webkit-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -o-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -ms-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f5f5f5', endColorstr='#eeeeee', GradientType=0);
}
.main-center{
 	margin-top: 30px;
 	margin: 0 auto;
 	max-width: 400px;
    padding: 10px 40px;
	background:#009edf;
	    color: #FFF;
    text-shadow: none;
	-webkit-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
-moz-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);

}
span.input-group-addon i {
    color: #009edf;
    font-size: 17px;
}

.login-button{
	margin-top: 5px;
}

.login-register{
	font-size: 11px;
	text-align: center;
}
footer{
    

}
.input-group-addon{
    width: 60px;
}
</style>
<style>
            /* The Modal (background) */
            .modal {
                display: none; /* Hidden by default */
                position: fixed; /* Stay in place */
                z-index: 1; /* Sit on top */
                left: 0;
                top: 0;
                width: 100%; /* Full width */
                height: 100%; /* Full height */
                overflow: auto; /* Enable scroll if needed */
                background-color: rgb(0,0,0); /* Fallback color */
                background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            }

            /* Modal Content/Box */
            .modal-content {
                background-color: #fefefe;
                margin: 15% auto; /* 15% from the top and centered */
                padding: 20px;
                border: 1px solid #888;
                width: 80%; /* Could be more or less, depending on screen size */
            }

            /* The Close Button */
            .close {
                color: #aaa;
                float: right;
                font-size: 28px;
                font-weight: bold;
            }

            .close:hover,
            .close:focus {
                color: black;
                text-decoration: none;
                cursor: pointer;
            }
            
            /* Modal Header */
.modal-header {
    padding: 2px 16px;
    background-color: #5cb85c;
    color: white;
}

/* Modal Body */
.modal-body {padding: 2px 16px;}

/* Modal Footer */
.modal-footer {
    padding: 2px 16px;
    background-color: #5cb85c;
    color: white;
}

/* Modal Content */
.modal-content {
    position: relative;
    background-color: #fefefe;
    margin: auto;
    padding: 0;
    border: 1px solid #888;
    width: 80%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-animation-name: animatetop;
    -webkit-animation-duration: 0.4s;
    animation-name: animatetop;
    animation-duration: 0.4s
}

/* Add Animation */
@-webkit-keyframes animatetop {
    from {top: -300px; opacity: 0} 
    to {top: 0; opacity: 1}
}

@keyframes animatetop {
    from {top: -300px; opacity: 0}
    to {top: 0; opacity: 1}
}
/*///////////////////////////////////////////////////////////////////////////////////////////*/
 .animated {
    -webkit-transition: height 0.2s;
    -moz-transition: height 0.2s;
    transition: height 0.2s;
}

.stars
{
    margin: 20px 0;
    font-size: 24px;
    color: #d17581;
}
        </style>
        
<div class="chatContainer">

    <div class="chatTitleContainer">Reviews</div>
	<div class="chatHistoryContainer">

        <ul class="formComments">
			<?php
                        if($Review_List !== FALSE){
                        foreach ($Review_List as $Review) {
                            
                        $commenter = new DO_users();
                        $commenter->get($Review->User_ID);
                        if($commenter->User_Verified == "Verified"){
                        echo '<li class="commentLi" style="margin-left: '.(($Review->Review_Level -1)*48).'px;" data-commentid="'.$Review->Review_ID.'">
				<table class="form-comments-table">
					<tbody><tr>
						<td><div class="comment-timestamp">'.$Review->Review_Date.'</div></td>
						<td><div class="comment-user">'.$commenter->User_NickName.'</div></td>
						<td>
							<div class="comment-avatar">
								'.'<img src="data:image/jpeg;base64,'.base64_encode( $commenter->User_Picture ).'"/>'.'
							</div>
						</td>
						<td>
							<div id="comment-'.$Review->Review_ID.'" data-commentid="'.$Review->Review_ID.'" class="comment comment-step1" style="opacity: 1; background-color: rgb(255, 255, 255); border-left-width: 1px;">
								'.$Review->Review  /**str_replace("\\r\\n", "<br />", $Review->Review)*/.'
                                <div id="commentactions-'.$Review->Review_ID.'" class="comment-actions" style="display: none;">
                                    <div class="btn-group" role="group" aria-label="..."><form action="index.php?Page=Reviews" method="POST"> <input type="hidden" name="ID" value="'. $ID. '"/><input type="hidden" name="Comment" value="'.$Review->Review_ID.'" >
                                    ';if(isset($_SESSION["username"])){if(true){echo '
                                    
                                    <button onclick="modalMaker(this)" value="Reply" type="button" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Reply</button> ';
                                    if(isset($currUser)){if($currUser->User_Role == "Admin"){    echo '<button type="button" value="Ban" onclick="modalMaker(this)" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>Ban</button>';}}
                                    }if($_SESSION["username"] == $commenter->User_NickName){echo '
                                    <button onclick="modalMaker(this)" value="Edit" type="button" class="btn btn-default btn-sm"><i class="fa fa-pencil"></i> Edit</button> ';}if($_SESSION["username"] == $commenter->User_NickName){echo '
                                    <button name="DELETE" value="DELETE" type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>Delete</button>';}} echo '
                                    </form>';if(isset($_SESSION["username"])){echo'<form class="rating"><input type="hidden" value="'.$_SESSION["username"].'">
  <label>
    <input type="radio" id="'.$Review->Review_ID.'"  name="RevRate" value="1" />
    <span class="icon">★</span>
  </label>
  <label>
    <input type="radio" id="'.$Review->Review_ID.'"  name="RevRate" value="2" />
    <span class="icon">★</span>
    <span class="icon">★</span>
  </label>
  <label>
    <input type="radio" id="'.$Review->Review_ID.'"  name="RevRate" value="3" />
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>   
  </label>
  <label>
    <input type="radio" id="'.$Review->Review_ID.'"  name="RevRate" value="4" />
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>
  </label>
  <label>
    <input type="radio" id="'.$Review->Review_ID.'" name="RevRate" value="5" />
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>
    <span class="icon">★</span>
  </label>
</form>';} echo '</div>                                 
                                </div>  
                            </div>
						</td>
					</tr>
				</tbody></table>
			</li> ';
                                    
                        }}}else{}?>
            
            
    		
            
            
            
            
            
        </ul>




	</div>
    <?php if(isset($_SESSION["username"])) : ?>
    <form id="messageForm" method="POST" action="index.php?Page=Reviews" enctype="multipart/form-data" >
    <div class="input-group input-group-sm chatMessageControls">
        <span class="input-group-addon" id="sizing-addon3">Comment</span>
        
        <textarea required name="Review" class="form-control" placeholder="Type your message here.." <?php
               if(!isset($_SESSION["username"])){                   echo 'disabled onclick="noUser()" '; }
               
               ?> aria-describedby="sizing-addon3" type="text"></textarea>
        <script>
               function noUser(){ alert("please login before writing a comment"); }                                                                                                                                                                                                                                                                                                               
        </script>    
        <span class="input-group-btn">
            <button id="clearMessageButton" class="btn btn-default" type="reset">Clear</button>
            <button onclick="document.getElementById('messageForm').submit()" id="sendMessageButton" <?php if(!isset($_SESSION["username"])){                   echo 'disabled="disabled"';}?> value="Send" name="submitted" class="btn btn-primary" type="button"><i class="fa fa-send"></i>Send</button>
            <input name="submitted" value="Send" type="hidden">
        </span>
        <!--<span class="input-group-btn">
            <button id="undoSendButton" class="btn btn-default" type="button" disabled="disabled"><i class="fa fa-undo"></i>Undo</button>
        </span>-->
    </div>
        <input type="hidden" name="ID" value="<?php echo $ID; ?>"/>
    </form>
    <!--<div class="container">
	<div class="row" style="margin-top:40px;">
		<div class="col-md-6">
    	<div class="well well-sm">
            <div class="text-right">
                <a class="btn btn-success btn-green" href="#reviews-anchor" id="open-review-box">Leave a Review</a>
            </div>
        
            <div class="row" id="post-review-box" style="display:none;">
                <div class="col-md-12">
                    <form accept-charset="UTF-8" action="" method="post">
                        <input id="ratings-hidden" name="rating" type="hidden"> 
                        <textarea class="form-control animated" cols="50" id="new-review" name="comment" placeholder="Enter your review here..." rows="5" style="overflow: hidden; overflow-wrap: break-word; resize: horizontal; height: 54px;"></textarea>
        
                        <div class="text-right">
                            <div class="stars starrr" data-rating="0"><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span><span class="glyphicon .glyphicon-star-empty glyphicon-star-empty"></span></div>
                            <a class="btn btn-danger btn-sm" href="#" id="close-review-box" style="display:none; margin-right: 10px;">
                            <span class="glyphicon glyphicon-remove"></span>Cancel</a>
                            <button class="btn btn-success btn-lg" type="submit">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div> 
         
		</div>
	</div>
</div>-->
    <?php endif; ?>
</div>
        <div id="myModal" class="modal">

                <!-- Modal content -->
                <div class="modal-content">
                    <div class="modal-header">
                        <span class="close">&times;</span>
                        <h2 id="modal_header" ></h2>
                    </div>
                    <div class="modal-body">
                        <form id="Modal_Form" method="POST" action="index.php?Page=Reviews">
                            
                            <textarea id="ModalTextArea" name="ModalTextArea"></textarea>
                            <input type="submit" id="ModalSubmit" name="ModalSubmit" value="Submit">
                            <input type="hidden" id="ModalRID" name="RID" value="">
                            <input type="hidden" id="ModalID" name="ID" value="">
                        </form>
                    </div>
                    
                </div>

            </div><!--<button id="myBtn">Open Modal</button>-->
        <script>
            // Get the modal
                var modal = document.getElementById('myModal');
                
            function modalMaker(btn)
            {
                
                    var form = btn.parentElement;
                    var facID = form.elements[0].value;
                    var ReviewID = form.elements[1].value;

                    //var rev = document.getElementById("comment-"+ReviewID).childNodes[0];

                    //console.log(document.getElementById("ModalTextArea"));
                    if(btn.value == "Reply")
                    {

                        document.getElementById("ModalSubmit").value = "Reply";
                        document.getElementById("ModalRID").value = ReviewID;
                        document.getElementById("ModalID").value = facID;
                        modal.style.display = "block";

                    }
                    else if(btn.value == "Edit")
                    {
                        //document.getElementById("ModalTextArea").value = rev;
                        document.getElementById("ModalSubmit").value = "Edit";
                        document.getElementById("ModalRID").value = ReviewID;
                        document.getElementById("ModalID").value = facID;
                        modal.style.display = "block";
                    
                    }
                    else if(btn.value == "Ban")
                    {
                        document.getElementById("ModalSubmit").value = "BanReview";
                        document.getElementById("ModalRID").value = ReviewID;
                        document.getElementById("ModalID").value = facID;
                        modal.style.display = "block";
                    }
            }
                

// Get the button that opens the modal
//                var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
                var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
                /*btn.onclick = function () {
                    modal.style.display = "block";
                }*/

// When the user clicks on <span> (x), close the modal
                span.onclick = function () {
                    modal.style.display = "none";
                }

// When the user clicks anywhere outside of the modal, close it
                window.onclick = function (event) {
                    if (event.target == modal) {
                        modal.style.display = "none";
                    }
                }
       
</script><div>
<!--<script src="js/dropDownScript.js" ></script>-->
<script src="js/StarRatingJS.js"></script>