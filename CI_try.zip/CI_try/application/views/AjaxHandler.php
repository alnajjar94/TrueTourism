<?php defined('BASEPATH') OR exit('No direct script access allowed');

if(!isset($_GET["q"]) && !isset($_GET["t"]))
{
    die('this page should not be accessed by users');
}

include_once 'application/models/mysqli_con.php';
include_once 'application/models/DO_Site_Facility.php';
include_once 'application/models/DO_Site.php';
include_once 'application/models/DO_users.php';
include_once 'application/models/DO_Reviews.php';
include_once 'application/models/DO_Site_Category.php';

$query_string = $_GET["q"];
$typeOfReturn = $_GET["t"];


if($typeOfReturn == "Site"):
    




    $Sites = new DO_Site();
    $Sites = $Sites->getByCategory($query_string);
    if($Sites)
    {
        $SitesList = '<select name="Site" id="Site" class="form-control" onchange="showFacility(this.value)" >';
        foreach ($Sites as $Site) {
            $SitesList .= "<option value=\"$Site->Site_ID\" > ".$Site->Site_Name."</option>";
        }
        $SitesList .= "</select>";
        
    }else
    {
        $SitesList = "<b style=\"color:red;\" id=\"Site\" > error : no sites were found </b>";
    }

    echo $SitesList;


elseif($typeOfReturn == "Facility"):
    
        $Facilities = new DO_Site_Facility();
        $Facilities = $Facilities->getBySite($query_string);
        if($Facilities)
        {
            $Facilities_List = '<select name="id" id="Facility" class="form-control"  >';
            foreach ($Facilities as $Facility) {
                $Facilities_List .= "<option value=\"$Facility->Facility_ID\"> ".$Facility->Facility_Name."</option>";
            }
            $Facilities_List .= "</select>";
        }
        else
        {
            $Facilities_List = "<b style=\"color:red;\" id=\"Facility\" > error : no Facilities were found </b>";
        }
    
        echo $Facilities_List;
endif;
?>



