<?php defined('BASEPATH') OR exit('No direct script access allowed');
include_once 'application/models/mysqli_con.php';
include_once 'application/models/DO_users.php';
/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if(isset($_SESSION["username"]))
{
    echo '<script> if(confirm("you are already logged in, please log out before logging in again for security reasons\n\nwould you like to log out now?")){window.location = "index.php?Page=Logout";}else{window.location = "index.php?Page=Home";}</script>';
}
if(isset($_GET["VN"]))
{
    try
    {
        $db = new mysqli_con();
        $dbc = $db->getConnection();
        $verify = new DO_users();
        if($verify->getUser($_GET["UID"]))
        {
            if($_GET["VN"] == $verify->User_Verification_Num)
            {
                if($verify->User_Verified = "Registered")
                {
                    $verify->User_Verified = "Verified";
                }

                $q = "update users set User_Verified='$verify->User_Verified' where User_ID=$verify->User_ID ";
                $r = mysqli_query($dbc, $q);
                if($r)
                {
                    $Success[] = "you have been successfully verified please login to the website";
                }
                else
                {
                    $Error[] = "database error contact the admin";
                }

            }
            else
            {
                $Error[] = "wrong verification number please make sure to use the provided verification number in your email \n "
                        . "or contact the admin";
                echo $_GET["VN"]." <br /> ";
                //print_r($verify);
            }
        }
        else
        {
            $Error[] = "couldnt retrieve user information";
        }
    } catch (Exception $ex) {
        $Error[] = "error processing your verification process please contact the admin";
    }
}


if(isset($_COOKIE["FBid"]))
{
    $db = new mysqli_con();
    $dbc = $db->getConnection();
    try {
        $FBuser = new DO_users();
    $_SESSION["FBid"] = $_COOKIE["FBid"];
    $_SESSION["FBname"] = $_COOKIE["FBname"];
    $_SESSION["FBemail"] = $_COOKIE["FBemail"];
    setcookie("FBid", "", time()-1);
    setcookie("FBname", "", time()-1);
    setcookie("FBemail", "", time()-1);
    $Success[] = "Facebook Login Success AS: ".$_SESSION["FBname"];



    if(!$FBuser->get($_SESSION["FBid"]))
    {
        $q = "INSERT INTO users(User_Picture,User_ID,User_Name,User_NickName,User_Email,User_Verified) "
                . "VALUES(?, ?, ?, ?, ?,'Verified')";
        $null = NULL;
        $FBuser->User_ID = $_SESSION["FBid"];
        $FBuser->User_Name = $_SESSION["FBname"];
        $FBuser->User_NickName = $_SESSION["FBname"];
        $FBuser->User_Email = $_SESSION["FBemail"];
        $stmt = $dbc->prepare($q);
        $stmt->bind_param('bssss', $null, $FBuser->User_ID, $FBuser->User_Name, $FBuser->User_NickName, $FBuser->User_Email);
        $stmt->send_long_data(0, file_get_contents("Pic/Superman_avatar.jpg"));
        $stmt->execute();
        $_SESSION["username"] = "$FBuser->User_NickName";
        $Success[] = 'Welcome MR.'.$FBuser->User_Name.' you will be redirected to home page in 5 seconds';
        echo '<script>setTimeout(function(){ window.location = "index.php?Page=Home"; }, 5000);</script>';
    }
    else
    {
        if($FBuser->User_Verified != "Blocked")
        {
            
            
            $Success[] = 'Welcome MR.'.$FBuser->User_Name.' you will be redirected to home page in 5 seconds';
            $_SESSION["username"] = "$FBuser->User_NickName";
            $Success[] = "Thanks for logging in again";
            echo '<script>setTimeout(function(){ window.location = "index.php?Page=Home"; }, 5000);</script>';
        }
        else
        {
            $Error[] = "you have been blocked please contact the admin for assistance.";
        }
    }
     
    //print_r($Success);
    } catch (Exception $ex) {
        $Error[] = "error processing your facebook login process please contact the admin";
        
    }
}


if($this->input->post('Submitted') !== NULL)
{
    
    
    $user = new DO_users();
    if($user->getUser($this->input->post('username')))
    {
        if($user->User_Verified == "Verified")
        {
            if($this->input->post('password') == $user->User_Password){
            $_SESSION["username"] = $user->User_NickName;
            $Success[] = 'Welcome MR.'.$user->User_Name.'you will be redirected to home page in 5 seconds';
            echo '<script>setTimeout(function(){ window.location = "index.php?Page=Home"; }, 5000);</script>';
            }
            else {
                $Error[] = 'Wrong Password please type it again';
            }
        }
        else
        {
            $Error[] = "user state is not stable : you have not verified your "
                    . "email or you are blocked. for further details please contact the admin";
        }
    }
    else
    {
        $Error[] = 'Error Retrieving user';
    }
     
}

if(isset($_SESSION['FBID']))
{
    echo $_SESSION['FBID'];
    echo $_SESSION['FULLNAME'];
    echo $_SESSION['EMAIL'];
}
?>


<script>
    /**
     * 
     * handle JS actions
     */
    function testAPI() {
    console.log('Welcome!  Fetching your information.... ');
    FB.api('/me', {fields: 'name, first_name,last_name, email'}, function(response) {
    console.log(response);
    document.cookie = "FBname="+response.name;
    document.cookie = "FBid="+response.id;
    document.cookie = "FBemail="+response.email;
    
    window.location = "index.php?Page=Login";
});}
/**
 * call JSFB SDK
 */
(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.11&appId=919511678206901';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>
<style>
    #playground-container {
    height: 500px;
    overflow: hidden !important;
    -webkit-overflow-scrolling: touch;
}
body, html{
        height: 100%;
 	
}
.MainBG{
    position: absolute;
width: 100%;
    background-repeat: no-repeat;
 	background:url(https://i.ytimg.com/vi/4kfXjatgeEU/maxresdefault.jpg);
 	font-family: 'Oxygen', sans-serif;
        background-size: cover;
        
}
.main{
 	margin:50px 15px;
}

h1.title { 
	font-size: 50px;
	font-family: 'Passion One', cursive; 
	font-weight: 400; 
}

hr{
	width: 10%;
	color: #fff;
}

.form-group{
	margin-bottom: 15px;
}

label{
	margin-bottom: 15px;
}

input,
input::-webkit-input-placeholder {
    font-size: 11px;
    padding-top: 3px;
}

.main-login{
 	background-color: #fff;
    /* shadows and rounded borders */
    -moz-border-radius: 2px;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);

}
.form-control {
    height: auto!important;
padding: 8px 12px !important;
}
.input-group {
    -webkit-box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
    -moz-box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
    box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
}
#button {
    border: 1px solid #ccc;
    margin-top: 28px;
    padding: 6px 12px;
    color: #666;
    text-shadow: 0 1px #fff;
    cursor: pointer;
    -moz-border-radius: 3px 3px;
    -webkit-border-radius: 3px 3px;
    border-radius: 3px 3px;
    -moz-box-shadow: 0 1px #fff inset, 0 1px #ddd;
    -webkit-box-shadow: 0 1px #fff inset, 0 1px #ddd;
    box-shadow: 0 1px #fff inset, 0 1px #ddd;
    background: #f5f5f5;
    background: -moz-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #f5f5f5), color-stop(100%, #eeeeee));
    background: -webkit-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -o-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -ms-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f5f5f5', endColorstr='#eeeeee', GradientType=0);
}
.main-center{
 	margin-top: 30px;
 	margin: 0 auto;
 	max-width: 400px;
    padding: 10px 40px;
	background:#009edf;
	    color: #FFF;
    text-shadow: none;
	-webkit-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
-moz-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);

}
span.input-group-addon i {
    color: #009edf;
    font-size: 17px;
}

.login-button{
	margin-top: 5px;
}

.login-register{
	font-size: 11px;
	text-align: center;
}
footer{
    
    display: hidden;
}
.input-group-addon{
    width: 60px;
}
</style>

<div class="container">
			<div class="row main">
				<div class="main-login main-center">
				<h5>Login to True Tourism.</h5>
                                <form class="" method="POST" action="index.php?Page=Login">
						
						

						<div class="form-group">
							<label for="username" class="cols-sm-2 control-label">username</label>
							<div class="cols-sm-10">
								<div class="input-group">
                                                                    <span class="input-group-addon">
                                                                        <img src="glyphicons/glyphicons-44-group.png" alt="username"/>
                                                                    </span>
                                                                    <input type="text" required class="form-control" name="username" id="username" value="<?php if($this->input->post('username') !== NULL){    echo $this->input->post('username');} ?>" placeholder="Enter your Username"/>
								</div>
							</div>
						</div>

						<div class="form-group">
							<label for="password" class="cols-sm-2 control-label">Password</label>
							<div class="cols-sm-10">
								<div class="input-group">
									<span class="input-group-addon">
                                                                            <img src="glyphicons/glyphicons-204-lock.png" alt="pass"/>
                                                                        </span>
									<input required type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password"/>
								</div>
							</div>
						</div>

						

						<div class="form-group ">
                                                    <input type="submit" id="button" name="Submitted" value="Login" class="btn btn-primary btn-lg btn-block login-button">
						</div>
						<h5>OR Sign in with</h5>
                                                <div class="form-group ">
                                                    <button onclick="testAPI()" id="login-btn" perms="user_friends, public_profile, email" scope="user_friends, public_profile, email" type="button" class="btn btn-primary btn-lg btn-block login-button"><img <?php //onclick="FB.login()" ?> src="Pic/Facebook2.png" class="img-thumbnail" alt="FB"/></button>
                                                    
						</div>
                                                
					</form>
                                <?php 
                                /**
                                 * display error and success
                                 */
                                
                                if(isset($Error[0])){

        
    
?>
<div class="alert alert-danger">
    <strong>There were Errors!</strong><br /><ul> <?php 
    
        foreach ($Error as $value) {
            echo "<li>$value</li>";
        }
    
    ?></ul>
</div>
<?php
    }
elseif(isset($Success[0])){
    


?>
<div class="alert alert-success">
  <strong>Success!</strong><br /> <ul><?php  
  
  foreach ($Success as $value) {
      echo "<li> $value </li>";
  }
  
  
  ?> </ul>
</div>
<?php

}?><?php

                                
                                
                                /**
                                 * end of messages display
                                 */
                                
                                
                                
                                
                                
                                ?>
				</div>
			</div>
		

		 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

                    <script>
                    document.getElementById('login-btn').onclick = function() {
                  FB.login(function(response) {
                    console.log(response);
                    testAPI();
                  }, {scope: 'user_friends, public_profile, email'});
                  return false;
                }
                </script>
                