<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>

<?php
if(session_destroy())
{
    echo "<script>alert(\"you are now logged out, you will be redirected to login screen\");</script>";
}
else
{
    echo '<script>alert(\"there was an error logging you out!\");</script>';
}
?>
<script>window.location = "index.php?Page=Login";</script>