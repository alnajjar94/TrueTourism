<?php defined('BASEPATH') OR exit('No direct script access allowed');
include_once 'application/models/mysqli_con.php'; 
include_once 'application/models/DO_Reviews.php';
include_once 'application/models/DO_users.php';
include_once 'application/models/DO_Site.php';
include_once 'application/models/DO_Site_Facility.php';
include_once 'application/models/DO_Review_Score.php';
include_once 'application/models/DO_facilities_Score.php';
$this->load->library('session');
static $Success = Array();

static $Error = Array();
/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

if(isset($_GET["RID"]))
{
    $user = new DO_users();
    $user->getUser($_SESSION["username"]);
    $db = new mysqli_con();
    $dbc = $db->getConnection();
    $q = "SELECT * FROM Review_Score WHERE `Review_ID`='$_GET[RID]' AND `User_ID`='$user->User_ID';";
    $r = mysqli_query($dbc, $q);
    if($r)
    {
        if(mysqli_num_rows($r) == 0)
        {
            $score = new DO_Review_Score();

            $score->User_ID = $user->User_ID;
            $score->Score = "$_GET[rating].00";
            $score->Review_ID = $_GET["RID"];
            $score->save();
            $Success[] = "Review Score Submitted";
        }
        else
        {
            $Error[] = "A user may only rate a review once";
        }
    }
    else
    {
        $Error[] = "database error occured";
        //$Error[] = mysqli_error($dbc);
        //$Error[] = $q;
    }
}
elseif(isset($_GET["FID"]))
{

    $user = new DO_users();
    $user->getUser($_SESSION["username"]);
    $db = new mysqli_con();
    $dbc = $db->getConnection();
    $q = "SELECT * FROM facilities_Score WHERE `Facility_ID`='$_GET[FID]' AND `User_ID`='$user->User_ID';";
    $r = mysqli_query($dbc, $q);
    if($r)
    {

        if(mysqli_num_rows($r) == 0)
        {

            $facRate = new DO_facilities_Score();
            $facRate->Facility_ID = $_GET["FID"];
            $facRate->Score = "$_GET[rating].00";
            $facRate->User_ID = $user->User_ID;
            $facRate->save();
            $Success[] = "Facility Score Submitted";
        }
        else 
        {
            $Error[] = "A user may only rate a Facility once";
        }
    }
    else
    {
        $Error[] = "a database error occurred please contact the admin";
    }
}


?><?php
if(isset($Error[0])){

        
    
?>

<div class="alert alert-danger">
    <strong>There were Errors!</strong><br /><ul> <?php 
    
        foreach ($Error as $value) {
            echo "<li>$value</li>";
        }
    
    ?></ul>
</div>
<?php
    }
elseif(isset($Success[0])){
    


?>
<div class="alert alert-success">
  <strong>Success!</strong><br /> <ul><?php  
  
  foreach ($Success as $value) {
      echo "<li> $value </li>";
  }
  
  
  ?> </ul>
</div>
<?php

}?>
