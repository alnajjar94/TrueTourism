<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>

</div>
<footer class="row" style="padding-top: 20px"><div class="col-md-12"><center><?php echo date('Y'); ?> TRUE TOURISM&COPY; ALL RIGHTS RESERVED </center></div>  </footer>
    </body>
</html>