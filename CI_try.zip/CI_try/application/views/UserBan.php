<?php defined('BASEPATH') OR exit('No direct script access allowed');

include_once 'application/models/mysqli_con.php';
include_once 'application/models/DO_Site.php';
include_once 'application/models/DO_Location.php';
include_once 'application/models/DO_Site_Category.php';
include_once 'application/models/DO_users.php';
include_once 'application/models/DO_Logs.php';
if(isset($_SESSION["username"]))
{
    $man = new DO_users();
    $man->getUser($_SESSION["username"]);
    if($man->User_Role != "Admin"){ die();}
}
/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 * 
 * ban scripting
 * 
 */
if(isset($_POST["ModalSubmit"]))
{
    $admin = new DO_users();
    $admin->getUser($_SESSION["username"]);
    if($_POST["ModalSubmit"] == "Ban")
    {
        $db = new mysqli_con();
        $dbc = $db->getConnection();
        $user = new DO_users();
        $user->get($_POST["UID"]);
        
        $q = "UPDATE `users` SET `User_Verified` = 'Blocked' WHERE `users`.`User_ID` = $user->User_ID;";
        $r = mysqli_query($dbc, $q);
        if($r)
        {
            $Success[] = "user have been successfully banned";
            $Log = new DO_Logs();
            $Log->Logged_Action = "a Ban of the user $user->User_NickName";
            $Log->Log_Message = "$_POST[ModalTextArea]";
            $Log->User_ID = $admin->User_NickName;
            if(!$Log->save())
            {
                $Error[] = "error at saving the logged message";
            }
        }
        else 
        {
            $Error[] = "Error banning user";
        }
    }
    else
    {
        $db = new mysqli_con();
        $dbc = $db->getConnection();
        $user = new DO_users();
        $user->get($_POST["UID"]);
        $q = "UPDATE `users` SET `User_Verified` = 'Verified' WHERE `users`.`User_ID` = $user->User_ID;";
        $r = mysqli_query($dbc, $q);
        if($r)
        {
            $Success[] = "user have been successfully unbanned";
            $Log = new DO_Logs();
            $Log->Logged_Action = "an unBan of the user $user->User_NickName";
            $Log->Log_Message = "$_POST[ModalTextArea]";
            $Log->User_ID = $admin->User_NickName;
            if(!$Log->save())
            {
                $Error[] = "error at saving the logged message";
            }
        }
        else 
        {
            $Error[] = "Error banning user";
        }
    }
}

$tmp = new DO_users();
$users = $tmp->getAll();

?>
<script src="js/jquery-1.js"></script><script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=ki8gx5frvdjovzusqj6657yi1kfd5i52xghdkcw4twevigx2"></script> <script>tinymce.init({ selector:'textarea' });</script>
<?php 
                                /**
                                 * display error and success
                                 */
                                
                                if(isset($Error[0])){

        
    
?>
<div class="alert alert-danger">
    <strong>There were Errors!</strong><br /><ul> <?php 
    
        foreach ($Error as $value) {
            echo "<li>$value</li>";
        }
    
    ?></ul>
</div>
<?php
    }
elseif(isset($Success[0])){
    


?>
<div class="alert alert-success">
  <strong>Success!</strong><br /> <ul><?php  
  
  foreach ($Success as $value) {
      echo "<li> $value </li>";
  }
  
  
  ?> </ul>
</div>
<?php

}?><?php

                                
                                
                                /**
                                 * end of messages display
                                 */
                                
                                
                                
                                
                                
                                ?>
<style>
            /* The Modal (background) */
            .modal {
                display: none; /* Hidden by default */
                position: fixed; /* Stay in place */
                z-index: 1; /* Sit on top */
                left: 0;
                top: 0;
                width: 100%; /* Full width */
                height: 100%; /* Full height */
                overflow: auto; /* Enable scroll if needed */
                background-color: rgb(0,0,0); /* Fallback color */
                background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            }

            /* Modal Content/Box */
            .modal-content {
                background-color: #fefefe;
                margin: 15% auto; /* 15% from the top and centered */
                padding: 20px;
                border: 1px solid #888;
                width: 80%; /* Could be more or less, depending on screen size */
            }

            /* The Close Button */
            .close {
                color: #aaa;
                float: right;
                font-size: 28px;
                font-weight: bold;
            }

            .close:hover,
            .close:focus {
                color: black;
                text-decoration: none;
                cursor: pointer;
            }
            
            /* Modal Header */
.modal-header {
    padding: 2px 16px;
    background-color: Red;
    color: white;
}

/* Modal Body */
.modal-body {padding: 2px 16px;}

/* Modal Footer */
.modal-footer {
    padding: 2px 16px;
    background-color: #5cb85c;
    color: white;
}

/* Modal Content */
.modal-content {
    position: relative;
    background-color: #fefefe;
    margin: auto;
    padding: 0;
    border: 1px solid #888;
    width: 80%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-animation-name: animatetop;
    -webkit-animation-duration: 0.4s;
    animation-name: animatetop;
    animation-duration: 0.4s
}

/* Add Animation */
@-webkit-keyframes animatetop {
    from {top: -300px; opacity: 0} 
    to {top: 0; opacity: 1}
}

@keyframes animatetop {
    from {top: -300px; opacity: 0}
    to {top: 0; opacity: 1}
}
/*///////////////////////////////////////////////////////////////////////////////////////////*/
 .animated {
    -webkit-transition: height 0.2s;
    -moz-transition: height 0.2s;
    transition: height 0.2s;
}

.stars
{
    margin: 20px 0;
    font-size: 24px;
    color: #d17581;
}
        </style>

<style>
#myInput {
    background-image: url('/css/searchicon.png'); /* Add a search icon to input */
    background-position: 10px 12px; /* Position the search icon */
    background-repeat: no-repeat; /* Do not repeat the icon image */
    width: 100%; /* Full-width */
    font-size: 16px; /* Increase font-size */
    padding: 12px 20px 12px 40px; /* Add some padding */
    border: 1px solid #ddd; /* Add a grey border */
    margin-bottom: 12px; /* Add some space below the input */
}

#myTable {
    border-collapse: collapse; /* Collapse borders */
    width: 100%; /* Full-width */
    border: 1px solid #ddd; /* Add a grey border */
    font-size: 18px; /* Increase font-size */
}

#myTable th, #myTable td {
    text-align: left; /* Left-align text */
    padding: 12px; /* Add padding */
}

#myTable tr td img{
    min-width: 50px;
    min-height: 50px;
}

#myTable tr {
    
    
    /* Add a bottom border to all table rows */
    border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
    /* Add a grey background color to the table header and on hover */
    background-color: #f1f1f1;
}
</style>
<div class="container">
<br />
<div class=" row">
    <input class="form-control col-12" type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names..">
</div>
<div class="row">
    <table id="myTable" class="table sm-col-12">
  <tr class="header">
    <th style="width:14%;">Name</th>
    <th style="width:14%;">User Picture</th>
    <th style="width:14%;">User Name</th>
    <th style="width:14%;">E-mail</th>
    <th style="width:14%;">Role</th>
    <th style="width:14%;">User Status</th>
    <th style="width:14%;">Ban/UnBan</th>
    
  </tr>
  
      <?php
        if($users)
        {
            
            foreach ($users as $user) {
                echo "<tr>"
                        . "<td>$user->User_Name</td>"
                        . "<td><img style=\"width:20%;height:20%\" src=\"data:image/jpeg;base64,".base64_encode( $user->User_Picture )."\"></td>"
                        . "<td>$user->User_NickName</td>"
                        . "<td>$user->User_Email</td>"
                        . "<td>$user->User_Role</td>"
                        . "<td>$user->User_Verified</td>"
                        . "<td> <button onclick=\"modalMaker(this)\" id=\"$user->User_ID\" name=\"banBtn\" value=\"".($user->User_Verified != "Blocked" ? "Ban" : "UnBan")."\" >".($user->User_Verified != "Blocked" ? "Ban" : "UnBan")."</button> </td>"//if banned then show unban
                    . "</tr>";
            }
        }
        else {
            echo "<tr><td colspan=\"4\"><center>No Users Are Available</center></td></tr>";
        }

      
    
      ?>
  
</table>
</div> 
</div>
<div id="myModal" class="modal">

                <!-- Modal content -->
                <div class="modal-content">
                    <div id="modalHeader" class="modal-header">
                        <span class="close">&times;</span>
                        <h2 id="modal_header" >Banning Reason</h2>
                    </div>
                    <div class="modal-body">
                        <form id="Modal_Form" method="POST" action="index.php?Page=UserBan">
                            
                            <textarea id="ModalTextArea" name="ModalTextArea"></textarea>
                            <input type="submit" id="ModalSubmit" name="ModalSubmit" value="Ban">
                            <input type="hidden" id="ModalUID" name="UID" value="">
                        </form>
                    </div>
                    
                </div>

            </div>
<script>
    
function myFunction() {
  // Declare variables
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[3];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}

</script>

<script>
    // Get the modal
                var modal = document.getElementById('myModal');
                
            function modalMaker(btn)
            {
                var mode = btn.value;
                var modalbtn = document.getElementById("ModalSubmit");
                modalbtn.value = mode;
                if(mode == "Ban")
                {
                    document.getElementById("modalHeader").style = "padding: 2px 16px;background-color: Red;color: white;";
                    document.getElementById("modal_header").innerHTML = "Banning Reason";
                }
                else
                {
                    document.getElementById("modalHeader").style = "padding: 2px 16px;background-color: Green;color: white;";
                    document.getElementById("modal_header").innerHTML = "Unbanning Reason";
                }
                var UID = btn.id;
                var modalUID = document.getElementById("ModalUID");
                modalUID.value = UID;
                modal.style.display = "block";
            }
                

// Get the button that opens the modal
//                var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
                var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
                /*btn.onclick = function () {
                    modal.style.display = "block";
                }*/

// When the user clicks on <span> (x), close the modal
                span.onclick = function () {
                    modal.style.display = "none";
                }

// When the user clicks anywhere outside of the modal, close it
                window.onclick = function (event) {
                    if (event.target == modal) {
                        modal.style.display = "none";
                    }
                }
       
</script>


