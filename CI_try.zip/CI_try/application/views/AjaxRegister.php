<?php defined('BASEPATH') OR exit('No direct script access allowed');
include_once 'application/models/mysqli_con.php'; 
include_once 'application/models/DO_Reviews.php';
include_once 'application/models/DO_users.php';
include_once 'application/models/DO_Site.php';
include_once 'application/models/DO_Site_Facility.php';
include_once 'application/models/DO_Review_Score.php';
include_once 'application/models/DO_facilities_Score.php';

/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

