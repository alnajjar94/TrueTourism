<?php defined('BASEPATH') OR exit('No direct script access allowed');
include_once 'application/models/mysqli_con.php'; 
include_once 'application/models/DO_Reviews.php';
include_once 'application/models/DO_users.php';
include_once 'application/models/DO_Site.php';
include_once 'application/models/DO_Site_Facility.php';
/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 * SELECT * FROM Site_Facility WHERE MATCH (Facility_Name,Facility_Description)
     AGAINST ('arad' IN BOOLEAN MODE);
 * 
 */
//-webkit-transition: width 0.4s ease-in-out;
//    transition: width 0.4s ease-in-out;
//}
$Facilities_List = FALSE;
$Review_List = FALSE;
if(isset($_POST["Search"]))
{
    $tmp = new DO_Reviews();
    $Review_List = $tmp->getBySearch($_POST["Search"]);
    $tmp = new DO_Site_Facility();
    $Facilities_List = $tmp->getBySearch($_POST["Search"]);
}
?>

<style>
    #flipkart-navbar {
    background-color: #2874f0;
    color: #FFFFFF;
}

.row1{
    padding-top: 10px;
}

.row2 {
    padding-bottom: 20px;
}

.flipkart-navbar-input {
    width: 90%;
    padding: 11px 16px;
    border-radius: 2px 0 0 2px;
    border: 0 none;
    outline: 0 none;
    font-size: 15px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}

/*.flipkart-navbar-input:focus {
    width: 90%;
    transition: width 0.4s ease-in-out;
}*/
.flipkart-navbar-button {
    background-color: #ffe11b;
    border: 1px solid #ffe11b;
    border-radius: 0 2px 2px 0;
    color: #565656;
    padding: 10px 0;
    height: 43px;
    cursor: pointer;
}

.cart-button {
    background-color: #2469d9;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .23), inset 1px 1px 0 0 hsla(0, 0%, 100%, .2);
    padding: 10px 0;
    text-align: center;
    height: 41px;
    border-radius: 2px;
    font-weight: 500;
    width: 120px;
    display: inline-block;
    color: #FFFFFF;
    text-decoration: none;
    color: inherit;
    border: none;
    outline: none;
}

.cart-button:hover{
    text-decoration: none;
    color: #fff;
    cursor: pointer;
}

.cart-svg {
    display: inline-block;
    width: 16px;
    height: 16px;
    vertical-align: middle;
    margin-right: 8px;
}

.item-number {
    border-radius: 3px;
    background-color: rgba(0, 0, 0, .1);
    height: 20px;
    padding: 3px 6px;
    font-weight: 500;
    display: inline-block;
    color: #fff;
    line-height: 12px;
    margin-left: 10px;
}

.upper-links {
    display: inline-block;
    padding: 0 11px;
    line-height: 23px;
    font-family: 'Roboto', sans-serif;
    letter-spacing: 0;
    color: inherit;
    border: none;
    outline: none;
    font-size: 12px;
}

.dropdown {
    position: relative;
    display: inline-block;
    margin-bottom: 0px;
}

.dropdown:hover {
    background-color: #fff;
}

.dropdown:hover .links {
    color: #000;
}

.dropdown:hover .dropdown-menu {
    display: block;
}

.dropdown .dropdown-menu {
    position: absolute;
    top: 100%;
    display: none;
    background-color: #fff;
    color: #333;
    left: 0px;
    border: 0;
    border-radius: 0;
    box-shadow: 0 4px 8px -3px #555454;
    margin: 0;
    padding: 0px;
}

.links {
    color: #fff;
    text-decoration: none;
}

.links:hover {
    color: #fff;
    text-decoration: none;
}

.profile-links {
    font-size: 12px;
    font-family: 'Roboto', sans-serif;
    border-bottom: 1px solid #e9e9e9;
    box-sizing: border-box;
    display: block;
    padding: 0 11px;
    line-height: 23px;
}

.profile-li{
    padding-top: 2px;
}

.largenav {
    display: none;
}

.smallnav{
    display: block;
}

.smallsearch{
    margin-left: 15px;
    margin-top: 15px;
}

.menu{
    cursor: pointer;
}

@media screen and (min-width: 768px) {
    .largenav {
        display: block;
    }
    .smallnav{
        display: none;
    }
    .smallsearch{
        margin: 0px;
    }
}

</style>
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

<div id="flipkart-navbar">
    <div class="container">
        <div class="row row1">
            
        </div>
        <div class="row row2">
            <div class="col-sm-2">
                <h2 style="margin:0px;"><span class="smallnav menu"> Search :</span></h2>
                <h1 style="margin:0px;"><span class="largenav">Search :</span></h1>
            </div>
            <div class="flipkart-navbar-search smallsearch col-sm-8 col-xs-11">
                <form action="index.php?Page=Search" method="POST"><div class="row">
                        <input required class="flipkart-navbar-input col-xs-11" type="text" Style="width: 85%; color: black;" placeholder="Search for Reviews" name="Search">
                    <button type="submit" class="flipkart-navbar-button col-xs-1" style="width: 10%; height: 44.5px;">
                        <svg width="15px" height="15px">
                            <path d="M11.618 9.897l4.224 4.212c.092.09.1.23.02.312l-1.464 1.46c-.08.08-.222.072-.314-.02L9.868 11.66M6.486 10.9c-2.42 0-4.38-1.955-4.38-4.367 0-2.413 1.96-4.37 4.38-4.37s4.38 1.957 4.38 4.37c0 2.412-1.96 4.368-4.38 4.368m0-10.834C2.904.066 0 2.96 0 6.533 0 10.105 2.904 13 6.486 13s6.487-2.895 6.487-6.467c0-3.572-2.905-6.467-6.487-6.467 "></path>
                        </svg>
                    </button>
                    
                </div></form>
            </div>
            
        </div>
    </div>
</div>
    
    
<?php
if($Facilities_List):



?>

<style>
    body {
    padding: 20px;
    font-family: 'Open Sans', sans-serif;
    background-color: #f7f7f7;
}

.lib-panel {
    margin-bottom: 20Px;
}
.lib-panel img {
    width: 100%;
    background-color: transparent;
}

.lib-panel .row,
.lib-panel .col-md-6 {
    padding: 0;
    background-color: #FFFFFF;
}


.lib-panel .lib-row {
    padding: 0 20px 0 20px;
}

.lib-panel .lib-row.lib-header {
    background-color: #FFFFFF;
    font-size: 20px;
    padding: 10px 20px 0 20px;
}

.lib-panel .lib-row.lib-header .lib-header-seperator {
    height: 2px;
    width: 26px;
    background-color: #d9d9d9;
    margin: 7px 0 7px 0;
}

.lib-panel .lib-row.lib-desc {
    position: relative;
    height: 100%;
    display: block;
    font-size: 13px;
}
.lib-panel .lib-row.lib-desc a{
    position: absolute;
    width: 100%;
    bottom: 10px;
    left: 20px;
}

.row-margin-bottom {
    margin-bottom: 20px;
}

.box-shadow {
    -webkit-box-shadow: 0 0 10px 0 rgba(0,0,0,.10);
    box-shadow: 0 0 10px 0 rgba(0,0,0,.10);
}

.no-padding {
    padding: 0;
}

</style>

<div class="container">
    <hr>
<?php
$count = 1;

foreach ($Facilities_List as $Facility) {
    

if(($count % 2) != 0)
{
    echo '<div class="row row-margin-bottom">';
}
else
{
    echo '<div class="col-md-1"></div>';
}
echo '
	
    
            
                
            <div class="col-md-5 no-padding lib-item" data-category="view">
                <div class="lib-panel">
                    <div class="row box-shadow">
                        <div class="col-md-6">
                            <img class="lib-img-show" src="data:image/jpeg;base64,'.base64_encode( $Facility->Facility_Picture ).'">
                        </div>
                        <div class="col-md-6">
                            <div class="lib-row lib-header">
                                <a href="index.php?Page=Reviews&ID='.$Facility->Facility_ID.'">'.$Facility->Facility_Name.'</a>
                                <div class="lib-header-seperator"></div>
                            </div>
                            <div class="lib-row lib-desc">
                                '.$Facility->Facility_Description.'
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
                
            
            
            /**echo '<div class="col-md-5 no-padding lib-item" data-category="ui">
                <div class="lib-panel">
                    <div class="row box-shadow">
                        <div class="col-md-6">
                            <img class="lib-img" src="Pic/Logo-PS.PNG">
                        </div>
                        <div class="col-md-6">
                            <div class="lib-row lib-header">
                                Example library
                                <div class="lib-header-seperator"></div>
                            </div>
                            <div class="lib-row lib-desc">
                                Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor Lorem ipsum dolor
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
';


*/
$count++;
}?>
    
    </div>
<?php endif; ?>

    
    
    <?php
if($Review_List !== FALSE){
    include 'application/views/scriptsForReviews.php';
    echo '<div class="chatContainer">

    <div class="chatTitleContainer">Reviews</div>
	<div class="chatHistoryContainer">

        <ul class="formComments">';
                        foreach ($Review_List as $Review) {
                            
                        $commenter = new DO_users();
                        $commenter->get($Review->User_ID);
                        echo '<a href="index.php?Page=Reviews&ID='.$Review->Facility_ID.'#commentactions-'.$Review->Review_ID.'" ><li class="commentLi commentstep-'.$Review->Review_Level.'" data-commentid="'.$Review->Review_ID.'">
				<table class="form-comments-table">
					<tbody><tr>
						<td><div class="comment-timestamp">'.$Review->Review_Date.'</div></td>
						<td><div class="comment-user">'.$commenter->User_NickName.'</div></td>
						<td>
							<div class="comment-avatar">
								'.'<img src="data:image/jpeg;base64,'.base64_encode( $commenter->User_Picture ).'"/>'.'
							</div>
						</td>
						<td>
							<div id="comment-'.$Review->Review_ID.'" data-commentid="'.$Review->Review_ID.'" class="comment comment-step1" style="opacity: 1; background-color: rgb(255, 255, 255); border-left-width: 1px;">
								'.$Review->Review.'
                                <div id="commentactions-'.$Review->Review_ID.'" class="comment-actions" style="display: none;">
                                    <div class="btn-group" role="group" aria-label="...">
                                    ';if(isset($_SESSION["username"])){if(true){echo '';}if($_SESSION["username"] == $commenter->User_NickName){echo '';}if($_SESSION["username"] == $commenter->User_NickName){echo '';}} echo '
                                    </div>                                
                                </div>
                            </div>
						</td>
					</tr>
				</tbody></table>
			</li> </a>';
                        
                        }
                        echo '   
            
            
            
            
        </ul>




	</div>
    
    
        
    
</div>';
                                    }else{}?>