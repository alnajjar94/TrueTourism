<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
include_once 'application/models/mysqli_con.php';
include_once 'application/models/DO_Site_Facility.php';
include_once 'application/models/DO_Site.php';
include_once 'application/models/DO_users.php';
include_once 'application/models/DO_Reviews.php';
include_once 'application/models/DO_Site_Category.php';
$db = new mysqli_con();
$dbc = $db->getConnection();
/**
 * get top facility////////////////////////////////////////////////////////////////////////////////
 */
//get the max out of the average scores from facilities scores
$q = "SELECT MAX(score) maxScore, Facility_ID FROM (SELECT AVG(Score) score, Facility_ID FROM facilities_Score GROUP BY Facility_ID) `average scores` ;";
$r = mysqli_query($dbc, $q);
if($r)
{
    $row = mysqli_fetch_array($r);
    $topFacScore = $row["maxScore"];
    $topFac = new DO_Site_Facility();
    $topFac->get($row["Facility_ID"]);
    $topSite = new DO_Site();
    $topSite->get($topFac->Site_ID);
    
}
 else {
    echo 'Database Error';
}



///get top facility/////////////////////////////////////////////////////////////////////////////
/**
 * get top review from a facility///////////////////////////////////////////////////////////////
 * query info :
 * SELECT : the maximum score and the review ID
 * FROM : average scores of all reviews and their IDs
 * WHERE : they are reviews of the selected facility
 */
$q = "SELECT MAX(score) `maxScore`, Review_ID FROM (SELECT AVG(Score) score, Review_ID FROM Review_Score GROUP BY Review_ID) `average scores` WHERE Review_ID IN (SELECT Review_ID FROM Reviews WHERE Facility_ID = $topFac->Facility_ID);";
$r = mysqli_query($dbc, $q);
if($r)
{
    
    $row = mysqli_fetch_array($r);
    $reviewScore = $row["maxScore"];
    $Review = new DO_Reviews();
    $Review->get($row["Review_ID"]);
}
else {
    echo 'Database ERROR';
}
///get top review from a facility/////////////////////////////////////////////////////////////
/**
 * Top Reviewer
 */
$q = "SELECT MAX(score) `maxScore`, Review_ID FROM (SELECT AVG(Score) score, Review_ID FROM Review_Score GROUP BY Review_ID) `average scores`";
$r = mysqli_query($dbc, $q);
if($r)
{
    
    $row = mysqli_fetch_array($r);
    $topReviewerScore = $row["maxScore"];
    $topReviewerReview = new DO_Reviews();
    $topReviewerReview->get($row["Review_ID"]);
    $topReviewer = new DO_users();
    $topReviewer->get($topReviewerReview->User_ID);
}
else
{
    echo 'Database ERROR';
}
///Top Reviewer//////////////////////////////////////////////////////////////////////////////
/**
 * Random Facility///////////////////////////////////////////////////////////////////////////
 */
$q = "SELECT * FROM Site_Facility ORDER BY RAND() LIMIT 1;";
$r = mysqli_query($dbc, $q);
if($r)
{
    $row = mysqli_fetch_array($r);
    $RandFacility = new DO_Site_Facility();
    $RandFacility->get($row["Facility_ID"]);
}
else
{
    echo 'Database ERRor';
}
///Random Facility////////////////////////////////////////////////////////////////////////////

/**
 * get top review from a facility///////////////////////////////////////////////////////////////
 * query info :
 * SELECT : the maximum score and the review ID
 * FROM : average scores of all reviews and their IDs
 * WHERE(HAVING) : they are reviews of the selected facility
 */
$q = "SELECT MAX(score) `maxScore`, Review_ID FROM (SELECT AVG(Score) score, Review_ID FROM Review_Score GROUP BY Review_ID) `average scores` WHERE Review_ID IN (SELECT Review_ID FROM Reviews WHERE Facility_ID = $RandFacility->Facility_ID);";
$r = mysqli_query($dbc, $q);
if($r)
{
    
    $row = mysqli_fetch_array($r);
    $randReviewScore = $row["maxScore"];
    $randReview = new DO_Reviews();
    //if random review is not found
    if(!$randReview->get($row["Review_ID"])){
        $randReview = NULL;
    }
}
else {
    echo 'Database ERROR';
}
///get top review from a facility/////////////////////////////////////////////////////////////
/**
 * get list of categories, sites and facilities.
 */
$categories = new DO_Site_Category();
$categories = $categories->getAll();
if($categories)
{
    $selectList = '<select name="category" id="category" class="form-control" onchange="showSite(this.value)" >';
    foreach ($categories as $category) {
        $selectList .= "<option value=\"$category->Category_ID\"> ".$category->Category_Name."</option>";
    }
    $selectList .= "</select>";
    
    $firstCategory = $categories[0];
    $Sites = new DO_Site();
    $Sites = $Sites->getByCategory($firstCategory->Category_ID);
    if($Sites)
    {
        $SitesList = '<select name="Site" id="Site" class="form-control" onchange="showFacility(this.value)" >';
        foreach ($Sites as $Site) {
            $SitesList .= "<option value=\"$Site->Site_ID\"> ".$Site->Site_Name."</option>";
        }
        $SitesList .= "</select>";
        $Facilities = new DO_Site_Facility();
        $Facilities = $Facilities->getBySite($Sites[0]->Site_ID);
        if($Facilities)
        {
            $Facilities_List = '<select name="id" id="Facility" class="form-control"  >';
            foreach ($Facilities as $Facility) {
                $Facilities_List .= "<option value=\"$Facility->Facility_ID\"> ".$Facility->Facility_Name."</option>";
            }
            $Facilities_List .= "</select>";
        }
        else
        {
            $Facilities_List = "<b style=\"color:red;\" id=\"Facility\" > error : no Facilities were found </b>";
        }
    }else
    {
        $SitesList = "<b style=\"color:red;\" id=\"Site\" > error : no sites were found </b>";
        $Facilities_List = "<b style=\"color:red;\" id=\"Facility\" > error : no Facilities were found </b>";
    }
}else
{
    $selectList = "<b style=\"color:red;\" id=\"category\" > error : no categories were found </b>";
    $SitesList = "<b style=\"color:red;\" id=\"Site\" > error : no sites were found </b>";
    $Facilities_List = "<b style=\"color:red;\" id=\"Facility\" > error : no Facilities were found </b>";
}
?>
<script>
    /**
     * 
     * @param {type} str
     * @return {undefined}
     */
function showFacility(Site)
{
  
//create the AJAX request object
  xmlhttp = new XMLHttpRequest();

  xmlhttp.open("GET", "index.php?q=" + Site +"&t=Facility&Page=AjaxHandler", true);
  xmlhttp.send();
   
   //declare a function that is called when something happens to the request
   xmlhttp.onreadystatechange = function()
   {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("Facility").outerHTML = xmlhttp.responseText;
        }
   }
 }
</script>
<script>
    /**
     * 
     * @param {type} Category
     * @return {undefined}
     */
function showSite(Category)
{
  
//create the AJAX request object
  xmlhttp = new XMLHttpRequest();

  xmlhttp.open("GET", "index.php?q=" + Category +"&t=Site&Page=AjaxHandler", true);
  xmlhttp.send();
   
   //declare a function that is called when something happens to the request
   xmlhttp.onreadystatechange = function()
   {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
        {
            document.getElementById("Site").outerHTML = xmlhttp.responseText;
        }
        
   }
   
   setTimeout( function(){
       if(document.getElementById("Site").firstChild.value != null)
        {
            showFacility(document.getElementById("Site").firstChild.value);
        }
        else
        {
            document.getElementById("Facility").outerHTML = "<b style=\"color:red;\" id=\"Facility\" > error : no Facilities were found </b>";
        }
   }, 1000);
   
   
   
 }
</script>

<style>
    #playground-container {
    height: 500px;
    overflow: hidden !important;
    -webkit-overflow-scrolling: touch;
}
body, html{
        height: 100%;
 	
}
.MainBG{
    position: absolute;
width: 100%;
    background-repeat: no-repeat;
 	background:url(https://i.ytimg.com/vi/4kfXjatgeEU/maxresdefault.jpg);
 	font-family: 'Oxygen', sans-serif;
        background-size: cover;
        
}
.main{
 	margin:50px 15px;
}

h1.title { 
	font-size: 50px;
	font-family: 'Passion One', cursive; 
	font-weight: 400; 
}

hr{
	width: 10%;
	color: #fff;
}

.form-group{
	margin-bottom: 15px;
}

label{
	margin-bottom: 15px;
}

input,
input::-webkit-input-placeholder {
    font-size: 11px;
    padding-top: 3px;
}

.main-login{
 	background-color: #fff;
    /* shadows and rounded borders */
    -moz-border-radius: 2px;
    -webkit-border-radius: 2px;
    border-radius: 2px;
    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);

}
.form-control {
    height: auto!important;
padding: 8px 12px !important;
}
.input-group {
    -webkit-box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
    -moz-box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
    box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.21)!important;
}
#button {
    border: 1px solid #ccc;
    margin-top: 28px;
    padding: 6px 12px;
    color: #666;
    text-shadow: 0 1px #fff;
    cursor: pointer;
    -moz-border-radius: 3px 3px;
    -webkit-border-radius: 3px 3px;
    border-radius: 3px 3px;
    -moz-box-shadow: 0 1px #fff inset, 0 1px #ddd;
    -webkit-box-shadow: 0 1px #fff inset, 0 1px #ddd;
    box-shadow: 0 1px #fff inset, 0 1px #ddd;
    background: #f5f5f5;
    background: -moz-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #f5f5f5), color-stop(100%, #eeeeee));
    background: -webkit-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -o-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: -ms-linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    background: linear-gradient(top, #f5f5f5 0%, #eeeeee 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f5f5f5', endColorstr='#eeeeee', GradientType=0);
}
.main-center{
 	margin-top: 30px;
 	margin: 0 auto;
 	max-width: 400px;
    padding: 10px 40px;
	background:#009edf;
	    color: #FFF;
    text-shadow: none;
	-webkit-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
-moz-box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);
box-shadow: 0px 3px 5px 0px rgba(0,0,0,0.31);

}
span.input-group-addon i {
    color: #009edf;
    font-size: 17px;
}

.login-button{
	margin-top: 5px;
}

.login-register{
	font-size: 11px;
	text-align: center;
}
footer{
    
    display: hidden;
}
.input-group-addon{
    width: 60px;
}
</style>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<div class="container">
    <br /><br /><br />
    <div class="row">
        <div class="col-1"></div>
        <div class="w3-card-4" style="width: 299px"><b>Top Site:</b> <br />
            <img width="299px" height="168px" src="<?php echo 'data:image/jpeg;base64,'.base64_encode( $topSite->Site_Picture ); ?>" alt="<?php echo "$topFac->Facility_Name"; ?>">
  <div class="w3-container w3-center">
      <p style="width: 299px; padding: 10px;padding-right: 30px;text-align:justify;"><?php echo "$topFac->Facility_Description"; ?></p>
  </div>
  <div class="w3-container w3-blue">
      <h5 style="width: 299px; padding: 10px;padding-right: 30px;text-align:justify;"><b>Site's Top Review: </b><br /><?php echo $Review->Review; ?></h5>
  </div>
</div> 
        <div class="col-4"></div>
        <div class="w3-card-4" style="width: 299px"><b>Top Reviewer:</b>
            <img width="299px" height="168px" src="<?php echo 'data:image/jpeg;base64,'.base64_encode( $topReviewer->User_Picture ); ?>" alt="<?php echo $topReviewer->User_NickName; ?>">
  <div class="w3-container w3-center">
      <p style="width: 299px; padding: 10px;padding-right: 30px;text-align:justify;"><b>Top Review: </b><br /><?php echo $topReviewerReview->Review; ?></p>
  </div>
            <div class="w3-container w3-blue">
      <h5 style="width: 299px; padding: 10px;padding-right: 30px;text-align:justify;"><br /><?php echo "This Review Gained the Average of : ".$topReviewerScore; ?></h5>
  </div>
</div> 
    
    </div>
    <!--new picture line-->
    <br /><br /><br />
    <div class="row">
        <div class="col-1"></div>
        <div class="w3-card-4" style="width: 299px"><b>Random Facility:</b> <br />
            <img width="299px" height="168px" src="<?php echo 'data:image/jpeg;base64,'.base64_encode($RandFacility->Facility_Picture); ?>" alt="Norway">
  <div class="w3-container w3-center">
    <p style="width: 299px; padding: 10px;padding-right: 30px;text-align:justify;"><?php echo $RandFacility->Facility_Description; ?></p>
  </div>
  <div class="w3-container w3-blue">
      <h5 style="width: 299px; padding: 10px;padding-right: 30px;text-align:justify;"><b>Site's Top Review: </b><br /><?php if($randReview !== NULL) {echo $randReview->Review;} else {
    echo '<b style="color:red;"> NO REVIEWS WERE FOUND YOU MAY ADD YOUR OWN REVIEW </b>';
} ?><br /><?php if($randReview !== NULL){echo "This Review Gained the Average of : ".$randReviewScore;} ?></h5>
  </div>
</div> 
        <div class="col-4"></div>
     <div class="w3-card-4" style="width: 299px">
  <div class="w3-container w3-center form-group">
      <p style="width: 299px; padding: 10px;padding-right: 30px;text-align:justify;"><form action="index.php?Page=Reviews" method="POST"><?php echo "Categories:<br />".$selectList;echo "<br />Sites:<br />".$SitesList;echo "<br />Facilities:<br />".$Facilities_List; ?><br /><button type="submit" name="HomeToReviews" value="TRUE">Fast Access</button></form></p>
  </div>
</div>
    
    </div>
    
    
    
    
    
    
    <br /><br /><br />