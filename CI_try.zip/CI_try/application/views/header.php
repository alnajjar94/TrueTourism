<?php defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->library('session');
static $Success = Array();
$this->load->view("SendMail");
static $Error = Array();
include_once 'application/models/mysqli_con.php';
include_once 'application/models/DO_users.php';
//$this->load->library('facebook');
/* 
 * author 201301587 Sayed Mohamed Alnajjar.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>



<html>
    <head>
        <title><?php if (isset($_GET["Page"])){ echo ucfirst($_GET["Page"])." | True Tourism";} else {    echo 'True Tourism';} ?></title>
        <meta charset="UTF-8">
        
        <link href="css/bootstrap-grid.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap-grid.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap-reboot.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap-reboot.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap-reboot.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" crossorigin="anonymous"></script>
        <script src="js/bootstrap.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <link href="css/my css.css" rel="stylesheet" type="text/css"/>
        <style>
    #flipkart-navbar {
    background-color: #2874f0;
    color: #FFFFFF;
}

.row1{
    padding-top: 10px;
}

.row2 {
    padding-bottom: 20px;
}

.flipkart-navbar-input {
    width: 90%;
    padding: 11px 16px;
    border-radius: 2px 0 0 2px;
    border: 0 none;
    outline: 0 none;
    font-size: 15px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
}

/*.flipkart-navbar-input:focus {
    width: 90%;
    transition: width 0.4s ease-in-out;
}*/
.flipkart-navbar-button {
    background-color: #ffe11b;
    border: 1px solid #ffe11b;
    border-radius: 0 2px 2px 0;
    color: #565656;
    padding: 10px 0;
    height: 43px;
    cursor: pointer;
}

.cart-button {
    background-color: #2469d9;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .23), inset 1px 1px 0 0 hsla(0, 0%, 100%, .2);
    padding: 10px 0;
    text-align: center;
    height: 41px;
    border-radius: 2px;
    font-weight: 500;
    width: 120px;
    display: inline-block;
    color: #FFFFFF;
    text-decoration: none;
    color: inherit;
    border: none;
    outline: none;
}

.cart-button:hover{
    text-decoration: none;
    color: #fff;
    cursor: pointer;
}

.cart-svg {
    display: inline-block;
    width: 16px;
    height: 16px;
    vertical-align: middle;
    margin-right: 8px;
}

.item-number {
    border-radius: 3px;
    background-color: rgba(0, 0, 0, .1);
    height: 20px;
    padding: 3px 6px;
    font-weight: 500;
    display: inline-block;
    color: #fff;
    line-height: 12px;
    margin-left: 10px;
}

.upper-links {
    display: inline-block;
    padding: 0 11px;
    line-height: 23px;
    font-family: 'Roboto', sans-serif;
    letter-spacing: 0;
    color: inherit;
    border: none;
    outline: none;
    font-size: 12px;
}

.dropdown {
    position: relative;
    display: inline-block;
    margin-bottom: 0px;
}

.dropdown:hover {
    background-color: #fff;
}

.dropdown:hover .links {
    color: #000;
}

.dropdown:hover .dropdown-menu {
    display: block;
}

.dropdown .dropdown-menu {
    position: absolute;
    top: 100%;
    display: none;
    background-color: #fff;
    color: #333;
    left: 0px;
    border: 0;
    border-radius: 0;
    box-shadow: 0 4px 8px -3px #555454;
    margin: 0;
    padding: 0px;
}

.links {
    color: #fff;
    text-decoration: none;
}

.links:hover {
    color: #fff;
    text-decoration: none;
}

.profile-links {
    font-size: 12px;
    font-family: 'Roboto', sans-serif;
    border-bottom: 1px solid #e9e9e9;
    box-sizing: border-box;
    display: block;
    padding: 0 11px;
    line-height: 23px;
}

.profile-li{
    padding-top: 2px;
}

.largenav {
    display: none;
}

.smallnav{
    display: block;
}

.smallsearch{
    margin-left: 15px;
    margin-top: 15px;
}

.menu{
    cursor: pointer;
}

@media screen and (min-width: 768px) {
    .largenav {
        display: block;
    }
    .smallnav{
        display: none;
    }
    .smallsearch{
        margin: 0px;
    }
}

</style>
        
    </head>
    <body>
        <style>@font-face {
    font-family: VRave;
    src: url(Fonts/Virtual-Rave.ttf);
}

.Font{
    font-family: VRave;
}
        </style>
            <header class="row">
                <div class="col-sm-3 align-content-center">
                    <img src="Pic/Logo-Top2.png" alt="True Tourism Logo" class="col-sm-12 img-thumbnail" style="min-height: 100px;min-width: 150px;"/>
                </div>
                <div class="Marquee col-sm-9 col-md-9">
                    <div class="bg">
                        <h3 style="color: skyblue;"><a style="font-family: oldy;">Welcome To True Tourism Where Truth be Told</a></h3>
                    </div>
                </div>
            </header>
            <nav class="navbar navbar-expand-md navbar-light">
      <a class="navbar-brand" href="#">True Tourism</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample03" aria-controls="navbarsExample03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExample03">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item <?php if (!isset($_GET["Page"])){ echo "active";} ?>">
              <a class="nav-link" href="index.php">Home <span class="sr-only"><?php if (!isset($_GET["Page"])){ echo "(current)";} ?></span></a>
          </li>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">User Links</a>
            <div class="dropdown-menu" aria-labelledby="dropdown03">
              <a class="dropdown-item" href="index.php?Page=UserInfo">User Profile</a>

              <a class="dropdown-item" href="index.php?Page=Contactus">Contact us</a>
              
              
            <a class="dropdown-item" href="index.php?Page=Register">Register <span class="sr-only"><?php if (isset($_GET["Page"])){ if($_GET["Page"] == "Register"){ echo "(current)";}} ?></a>
          
          
            <a class="dropdown-item" href="index.php?Page=Login">Login <span class="sr-only"><?php if (isset($_GET["Page"])){ if($_GET["Page"] == "Login"){ echo "(current)";}} ?></a>
          <a class="dropdown-item" href="index.php?Page=Logout">Logout <span class="sr-only"><?php if (isset($_GET["Page"])){ if($_GET["Page"] == "Logout"){ echo "(current)";}} ?></a>

            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="http://example.com" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">User Options</a>
            <div class="dropdown-menu" aria-labelledby="dropdown03">
              
              <a class="dropdown-item" href="index.php?Page=Search">Search</a>
              <a class="dropdown-item" href="index.php?Page=Contactus">Contact us</a>
              <a class="dropdown-item" href="index.php?Page=SiteList">Sites List</a>


            </div>
          </li><?php if (isset($_SESSION["username"])){ $man = new DO_users(); $man->getUser($_SESSION["username"]); if($man->User_Role == "Admin") {echo '
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="http://example.com" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Admin Pages</a>
            <div class="dropdown-menu" aria-labelledby="dropdown03">
              <a class="dropdown-item" href="index.php?Page=UserBan">User Ban</a>
              <a class="dropdown-item" href="index.php?Page=FacAdd">Facilities Add</a>
              <a class="dropdown-item" href="index.php?Page=SiteAdd">Sites Add</a>
              <a class="dropdown-item" href="index.php?Page=AdminLogs">Logs</a>
            </div>
          </li>'; }}?>
          <!--<li class="nav-item <?php if (isset($_GET["Page"])){ if($_GET["Page"] == "Register"){ echo "active";}} ?>">
            <a class="nav-link" href="index.php?Page=Register">Register <span class="sr-only"><?php if (isset($_GET["Page"])){ if($_GET["Page"] == "Register"){ echo "(current)";}} ?></a>
          </li>
          <li class="nav-item <?php if (isset($_GET["Page"])){ if($_GET["Page"] == "Reviews"){ echo "active";}} ?>">
            <a class="nav-link" href="index.php?Page=Reviews">Add Review <span class="sr-only"><?php if (isset($_GET["Page"])){ if($_GET["Page"] == "Reviews"){ echo "(current)";}} ?></a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="http://example.com" id="dropdown03" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dropdown</a>
            <div class="dropdown-menu" aria-labelledby="dropdown03">
              <a class="dropdown-item" href="index.php?Page=UserInfo">User Profile</a>
              <a class="dropdown-item" href="index.php?Page=Search">Search</a>
              <a class="dropdown-item" href="index.php?Page=Contactus">Contact us</a>
              <a class="dropdown-item" href="index.php?Page=SiteList">Sites List</a>
              <a class="dropdown-item" href="index.php?Page=UserBan">User Ban</a>
              <a class="dropdown-item" href="index.php?Page=FacAdd">Facilities Add</a>
              <a class="dropdown-item" href="index.php?Page=SiteAdd">Sites Add</a>
              <a class="dropdown-item" href="index.php?Page=AdminLogs">Logs</a>
            </div>
          </li>-->
        </ul>
          
              
          
        <form class="form-inline my-2 my-md-0">
            <div id="google_translate_element"></div><script type="text/javascript">
function fixDir()
{
    var a = document.getElementsByClassName("goog-te-menu-value")[0];
    var spanTxt = a.firstElementChild;
    var lang = spanTxt.textContent;
    if(lang === "Arabic")
    {
        var body = document.getElementsByTagName("Body")[0];
        body.dir = "rtl";
    }
    else if(lang === "Persian")
    {
        var body = document.getElementsByTagName("Body")[0];
        body.dir = "rtl";
    }
    else
    {
        var body = document.getElementsByTagName("Body")[0];
        body.dir = "ltr";
    }
}

function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE, autoDisplay: false}, 'google_translate_element');
}
window.onload = myInit;
function myInit()
{
    var a = document.getElementsByClassName("goog-te-menu-value")[0];
    var spanTxt = a.firstElementChild;
    //spanTxt.onchange = fixDir;
    //spanTxt.addEventListener("change", fixDir());
    setInterval(fixDir, 1000);
}

</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
         
        </form>
          <ul class="navbar-nav">
              <li class="nav-item">
                  <?php
                  
                  if(!isset($_SESSION["username"]))
                  {
                      echo "<a class=\"nav-link\" href=\"index.php?Page=Login\"><img src=\"glyphicons/glyphicons-4-user.png\" alt=\"normal user glyphicon\"/>Sign in</a>";
                      
                  }
                  else
                  {
                      echo "<a class=\"nav-link\" href=\"index.php?Page=Logout\"><img src=\"glyphicons/glyphicons-4-user.png\" alt=\"normal user glyphicon\"/>".$_SESSION["username"]."</a>";
                  }
                  ?>
              </li>
          </ul>
      </div>
    </nav>
            <!--<main class="container-fluid">
                <div class="row">
                    <div class="col-2"></div>
                    <div class="col-4"><a title="change to arabic language"><img src="Pic/images.jpg" alt="Bahrain Flag" class="img-thumbnail language-flag"/></a></div>
                    <div class="col-4"><a title="change to english language"><img src="Pic/colors_of_england_201015.jpg" alt="Britain Flag" class="img-thumbnail language-flag"/></a></div>
                    <div class="col-2"></div>
                </div>
            </main>-->
        
            <div class="MainBG">