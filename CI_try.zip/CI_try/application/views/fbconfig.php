<?php defined('BASEPATH') OR exit('No direct script access allowed');
//session_start();
// added in v4.0.0
include_once 'src/Facebook/FacebookSession.php';
include_once 'src/Facebook/FacebookRedirectLoginHelper.php';
include_once 'src/Facebook/FacebookRequest.php';
include_once 'src/Facebook/FacebookResponse.php';
include_once 'src/Facebook/FacebookSDKException.php';
include_once 'src/Facebook/FacebookRequestException.php';
include_once 'src/Facebook/FacebookAuthorizationException.php';
include_once 'src/Facebook/GraphObject.php';
include_once 'src/Facebook/Entities/AccessToken.php';
include_once 'src/Facebook/Entities/SignedRequest.php';
include_once 'src/Facebook/HttpClients/FacebookHttpable.php';
include_once 'src/Facebook/HttpClients/FacebookCurlHttpClient.php';

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
require_once 'autoload.php';
use Facebook\FacebookSession;
use Facebook\FacebookRedirectLoginHelper;
use Facebook\FacebookRequest;
use Facebook\FacebookResponse;
use Facebook\FacebookSDKException;
use Facebook\FacebookRequestException;
use Facebook\FacebookAuthorizationException;
use Facebook\GraphObject;
use Facebook\Entities\AccessToken;
use Facebook\HttpClients\FacebookCurlHttpClient;
use Facebook\HttpClients\FacebookHttpable;
// init app with app id and secret
FacebookSession::setDefaultApplication( '919511678206901','91d9d19bf00783399fc111f2c6fa37c9' );
// login helper with redirect_uri
    $helper = new FacebookRedirectLoginHelper('http://ec2-54-171-69-5.eu-west-1.compute.amazonaws.com/CI_try/index.php' ,'919511678206901','91d9d19bf00783399fc111f2c6fa37c9');
try {
  $session = $helper->getSessionFromRedirect();
} catch( FacebookRequestException $ex ) {
  // When Facebook returns an error
} catch( Exception $ex ) {
  // When validation fails or other local issues
}
// see if we have a session
if ( isset( $session ) ) {
  // graph api request for user data
  $request = new FacebookRequest( $session, 'GET', '/me' );
  $response = $request->execute();
  // get response
  $graphObject = $response->getGraphObject();
     	$fbid = $graphObject->getProperty('id');              // To Get Facebook ID
 	    $fbfullname = $graphObject->getProperty('name'); // To Get Facebook full name
	    $femail = $graphObject->getProperty('email');    // To Get Facebook email ID
	/* ---- Session Variables -----*/
	    $_SESSION['FBID'] = $fbid;           
        $_SESSION['FULLNAME'] = $fbfullname;
	    $_SESSION['EMAIL'] =  $femail;
    /* ---- header location after session ----*/
  header("Location: index.php");
} else {
  $loginUrl = $helper->getLoginUrl();
 header("Location: ".$loginUrl);
}
?>