$(':radio[name=FacRate]').change(function() {
//  console.log('New Facility star rating: ' + this.value + ' for id: ' + this.id);
  var FID = this.id;
  var rating = this.value;
  $.ajax({url: "index.php?Page=AjaxReviews&rating="+rating+"&FID="+FID, success: function(result){
        $("#Results").html(result);
    }});
}); 

$(':radio[name=RevRate]').change(function() {
  //console.log('New Review star rating: ' + this.value + ' for id: ' + this.id);
  var RID = this.id;
  var rating = this.value;
  //console.log(this.parentElement.parentElement);
  $.ajax({url: "index.php?Page=AjaxReviews&rating="+rating+"&RID="+RID, success: function(result){
        $("#Results").html(result);
    }});
});




